import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useStudyStore } from '@/hooks/useStudyStore';
import { useAuth } from '@/auth/AuthProvider';
import { AuthPanel } from '@/auth/AuthPanel';
import Navigation from '@/components/Navigation';
import HeroSection from '@/sections/HeroSection';
import TutorSection from '@/sections/TutorSection';
import FlashcardsSection from '@/sections/FlashcardsSection';
import QuizSection from '@/sections/QuizSection';
import GamesSection from '@/sections/GamesSection';
import HowItWorksSection from '@/sections/HowItWorksSection';
import StudySetsSection from '@/sections/StudySetsSection';
import ProgressSection from '@/sections/ProgressSection';
import TestimonialsSection from '@/sections/TestimonialsSection';
import PricingSection from '@/sections/PricingSection';
import FAQSection from '@/sections/FAQSection';
import CTASection from '@/sections/CTASection';
import Dashboard from '@/components/Dashboard';
import { Toaster } from '@/components/ui/sonner';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);
  const { isLoaded } = useStudyStore();
  const { user, loading: authLoading } = useAuth();

  // Global scroll snap for pinned sections
  useEffect(() => {
    if (!isLoaded) return;

    // Wait for all ScrollTriggers to be created
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      if (!maxScroll || pinned.length === 0) return;

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(
              r => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            if (!inPinned) return value;

            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [isLoaded]);

  // Cleanup ScrollTriggers on unmount
  useEffect(() => {
    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="orb" />
        <Toaster />
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <AuthPanel />
        <Toaster />
      </>
    );
  }

  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="orb" />
        <Toaster />
      </div>
    );
  }

  return (
    <div ref={mainRef} className="relative">
      {/* Background Layer */}
      <div className="bg-layer bg-layer-mesh" aria-hidden />

      {/* Navigation */}
      <Navigation />

      {/* Main Content */}
      <main className="relative z-10">
        {/* Landing Page Sections */}
        <div id="landing">
          <HeroSection />
          <TutorSection />
          <FlashcardsSection />
          <QuizSection />
          <GamesSection />
          <HowItWorksSection />
          <StudySetsSection />
          <ProgressSection />
          <TestimonialsSection />
          <PricingSection />
          <FAQSection />
          <CTASection />
        </div>

        {/* Dashboard (hidden by default, shown via navigation) */}
        <Dashboard />
      </main>

      <Toaster />
    </div>
  );
}

export default App;