import { useState, useEffect, useCallback, useMemo } from 'react';
import type { StudySet, Flashcard, QuizQuestion, StudySession, UserProgress, Note, GameScore, TutorMessage, StudyPlan } from '@/types';
import { scheduleReview, type SrsRating } from '@/lib/srs';
import { useAuth } from '@/auth/AuthProvider';

const generateId = () => Math.random().toString(36).substring(2, 15);

const parseDate = (v: unknown): Date | undefined => {
  if (v == null) return undefined;
  if (v instanceof Date) return v;
  const d = new Date(v as string);
  return Number.isNaN(d.getTime()) ? undefined : d;
};

/** Restore Date fields after localStorage JSON.parse */
function hydrateState(raw: {
  studySets?: StudySet[];
  studySessions?: StudySession[];
  notes?: Note[];
  gameScores?: GameScore[];
  tutorMessages?: Record<string, TutorMessage[]>;
  studyPlans?: StudyPlan[];
  userProgress?: UserProgress;
}): void {
  if (raw.studySets) {
    raw.studySets = raw.studySets.map((s) => ({
      ...s,
      createdAt: parseDate(s.createdAt) ?? new Date(),
      updatedAt: parseDate(s.updatedAt) ?? new Date(),
      flashcards: (s.flashcards || []).map((fc) => ({
        ...fc,
        lastReviewed: parseDate(fc.lastReviewed),
        nextReview: parseDate(fc.nextReview),
        easeFactor: fc.easeFactor ?? 2.5,
        intervalDays: fc.intervalDays ?? 0,
        repetitions: fc.repetitions ?? 0,
      })),
      quizQuestions: s.quizQuestions || [],
    }));
  }
  if (raw.studySessions) {
    raw.studySessions = raw.studySessions.map((sess) => ({
      ...sess,
      startedAt: parseDate(sess.startedAt) ?? new Date(),
      endedAt: parseDate(sess.endedAt),
    }));
  }
  if (raw.notes) {
    raw.notes = raw.notes.map((n) => ({
      ...n,
      createdAt: parseDate(n.createdAt) ?? new Date(),
      updatedAt: parseDate(n.updatedAt) ?? new Date(),
    }));
  }
  if (raw.gameScores) {
    raw.gameScores = raw.gameScores.map((g) => ({
      ...g,
      completedAt: parseDate(g.completedAt) ?? new Date(),
    }));
  }
  if (raw.tutorMessages) {
    const entries: Record<string, TutorMessage[]> = {};
    for (const [k, msgs] of Object.entries(raw.tutorMessages)) {
      entries[k] = (msgs || []).map((m) => ({
        ...m,
        timestamp: parseDate(m.timestamp) ?? new Date(),
      }));
    }
    raw.tutorMessages = entries;
  }
  if (raw.studyPlans) {
    raw.studyPlans = raw.studyPlans.map((p) => ({
      ...p,
      targetDate: parseDate(p.targetDate) ?? new Date(),
    }));
  }
  if (raw.userProgress) {
    raw.userProgress = {
      ...raw.userProgress,
      lastStudyDate: parseDate(raw.userProgress.lastStudyDate),
    };
  }
}

const createDefaultFlashcards = (content: string): Flashcard[] => {
  const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 20).slice(0, 10);
  return sentences.map((sentence, i) => ({
    id: generateId(),
    front: `What is the key concept in: "${sentence.trim().substring(0, 60)}..."?`,
    back: sentence.trim(),
    difficulty: i % 3 === 0 ? 'easy' : i % 3 === 1 ? 'medium' : 'hard',
    timesReviewed: 0,
    timesCorrect: 0,
    easeFactor: 2.5,
    intervalDays: 0,
    repetitions: 0,
  }));
};

const createDefaultQuizQuestions = (content: string): QuizQuestion[] => {
  const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 20).slice(0, 5);
  return sentences.map((sentence) => ({
    id: generateId(),
    question: `Based on the following, what is being described? "${sentence.trim().substring(0, 80)}..."`,
    options: [
      sentence.trim().substring(0, 40),
      'A different concept entirely',
      'Related but incorrect information',
      'None of the above',
    ],
    correctAnswer: 0,
    explanation: `The correct answer is derived from: ${sentence.trim()}`,
    type: 'multiple_choice',
  }));
};

const colors = ['#B8B2F7', '#7DD3FC', '#86EFAC', '#FDE047', '#FCA5A5', '#C4B5FD'];

export const useStudyStore = () => {
  const { user } = useAuth();
  const storage = useMemo(() => {
    if (!user?.id) return null;
    const prefix = `vantage:${user.id}`;
    return {
      studySets: `${prefix}:study_sets`,
      studySessions: `${prefix}:study_sessions`,
      notes: `${prefix}:notes`,
      gameScores: `${prefix}:game_scores`,
      tutorMessages: `${prefix}:tutor_messages`,
      studyPlans: `${prefix}:study_plans`,
      userProgress: `${prefix}:user_progress`,
    };
  }, [user?.id]);

  const [studySets, setStudySets] = useState<StudySet[]>([]);
  const [studySessions, setStudySessions] = useState<StudySession[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [gameScores, setGameScores] = useState<GameScore[]>([]);
  const [tutorMessages, setTutorMessages] = useState<Record<string, TutorMessage[]>>({});
  const [studyPlans, setStudyPlans] = useState<StudyPlan[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress>({
    totalStudySets: 0,
    totalFlashcards: 0,
    totalStudySessions: 0,
    weeklyGoal: 20,
    weeklyProgress: 0,
    currentStreak: 0,
    longestStreak: 0,
    totalStudyTime: 0,
    masteryScore: 0,
    pomodoroSessionsCompleted: 0,
  });
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from localStorage when auth/user changes
  useEffect(() => {
    if (!storage) {
      setIsLoaded(false);
      setStudySets([]);
      setStudySessions([]);
      setNotes([]);
      setGameScores([]);
      setTutorMessages({});
      setStudyPlans([]);
      setUserProgress({
        totalStudySets: 0,
        totalFlashcards: 0,
        totalStudySessions: 0,
        weeklyGoal: 20,
        weeklyProgress: 0,
        currentStreak: 0,
        longestStreak: 0,
        totalStudyTime: 0,
        masteryScore: 0,
        pomodoroSessionsCompleted: 0,
      });
      return;
    }

    const loadData = () => {
      try {
        const savedSets = localStorage.getItem(storage.studySets);
        const savedSessions = localStorage.getItem(storage.studySessions);
        const savedNotes = localStorage.getItem(storage.notes);
        const savedScores = localStorage.getItem(storage.gameScores);
        const savedMessages = localStorage.getItem(storage.tutorMessages);
        const savedPlans = localStorage.getItem(storage.studyPlans);
        const savedProgress = localStorage.getItem(storage.userProgress);

        const payload: Parameters<typeof hydrateState>[0] = {};
        if (savedSets) payload.studySets = JSON.parse(savedSets);
        if (savedSessions) payload.studySessions = JSON.parse(savedSessions);
        if (savedNotes) payload.notes = JSON.parse(savedNotes);
        if (savedScores) payload.gameScores = JSON.parse(savedScores);
        if (savedMessages) payload.tutorMessages = JSON.parse(savedMessages);
        if (savedPlans) payload.studyPlans = JSON.parse(savedPlans);
        if (savedProgress) payload.userProgress = JSON.parse(savedProgress);
        hydrateState(payload);
        if (payload.studySets) setStudySets(payload.studySets);
        if (payload.studySessions) setStudySessions(payload.studySessions);
        if (payload.notes) setNotes(payload.notes);
        if (payload.gameScores) setGameScores(payload.gameScores);
        if (payload.tutorMessages) setTutorMessages(payload.tutorMessages);
        if (payload.studyPlans) setStudyPlans(payload.studyPlans);
        if (payload.userProgress) {
          setUserProgress((prev) => ({
            ...prev,
            ...payload.userProgress,
            pomodoroSessionsCompleted:
              payload.userProgress!.pomodoroSessionsCompleted ?? prev.pomodoroSessionsCompleted ?? 0,
          }));
        }
      } catch (error) {
        console.error('Error loading data:', error);
      }
      setIsLoaded(true);
    };
    loadData();
  }, [storage]);

  // Save to localStorage on changes
  useEffect(() => {
    if (!isLoaded || !storage) return;
    localStorage.setItem(storage.studySets, JSON.stringify(studySets));
  }, [studySets, isLoaded, storage]);

  useEffect(() => {
    if (!isLoaded || !storage) return;
    localStorage.setItem(storage.studySessions, JSON.stringify(studySessions));
  }, [studySessions, isLoaded, storage]);

  useEffect(() => {
    if (!isLoaded || !storage) return;
    localStorage.setItem(storage.notes, JSON.stringify(notes));
  }, [notes, isLoaded, storage]);

  useEffect(() => {
    if (!isLoaded || !storage) return;
    localStorage.setItem(storage.gameScores, JSON.stringify(gameScores));
  }, [gameScores, isLoaded, storage]);

  useEffect(() => {
    if (!isLoaded || !storage) return;
    localStorage.setItem(storage.tutorMessages, JSON.stringify(tutorMessages));
  }, [tutorMessages, isLoaded, storage]);

  useEffect(() => {
    if (!isLoaded || !storage) return;
    localStorage.setItem(storage.studyPlans, JSON.stringify(studyPlans));
  }, [studyPlans, isLoaded, storage]);

  useEffect(() => {
    if (!isLoaded || !storage) return;
    localStorage.setItem(storage.userProgress, JSON.stringify(userProgress));
  }, [userProgress, isLoaded, storage]);

  const createStudySet = useCallback((name: string, content: string) => {
    const newSet: StudySet = {
      id: generateId(),
      name,
      content,
      createdAt: new Date(),
      updatedAt: new Date(),
      flashcards: createDefaultFlashcards(content),
      quizQuestions: createDefaultQuizQuestions(content),
      color: colors[Math.floor(Math.random() * colors.length)],
    };
    setStudySets(prev => [newSet, ...prev]);
    setUserProgress(prev => ({
      ...prev,
      totalStudySets: prev.totalStudySets + 1,
      totalFlashcards: prev.totalFlashcards + newSet.flashcards.length,
    }));
    return newSet.id;
  }, []);

  const deleteStudySet = useCallback((id: string) => {
    setStudySets(prev => {
      const set = prev.find(s => s.id === id);
      if (set) {
        setUserProgress(p => ({
          ...p,
          totalStudySets: p.totalStudySets - 1,
          totalFlashcards: p.totalFlashcards - set.flashcards.length,
        }));
      }
      return prev.filter(s => s.id !== id);
    });
    setNotes(prev => prev.filter(n => n.setId !== id));
  }, []);

  const updateFlashcard = useCallback((setId: string, flashcardId: string, updates: Partial<Flashcard>) => {
    setStudySets(prev => prev.map(set => {
      if (set.id !== setId) return set;
      return {
        ...set,
        flashcards: set.flashcards.map(fc =>
          fc.id === flashcardId ? { ...fc, ...updates } : fc
        ),
      };
    }));
  }, []);

  const addFlashcard = useCallback((setId: string, front: string, back: string) => {
    const newCard: Flashcard = {
      id: generateId(),
      front,
      back,
      difficulty: 'medium',
      timesReviewed: 0,
      timesCorrect: 0,
      easeFactor: 2.5,
      intervalDays: 0,
      repetitions: 0,
    };
    setStudySets(prev => prev.map(set => {
      if (set.id !== setId) return set;
      return {
        ...set,
        flashcards: [...set.flashcards, newCard],
      };
    }));
    setUserProgress(prev => ({ ...prev, totalFlashcards: prev.totalFlashcards + 1 }));
  }, []);

  const addQuizQuestion = useCallback((setId: string, question: Omit<QuizQuestion, 'id'>) => {
    const newQuestion: QuizQuestion = {
      ...question,
      id: generateId(),
    };
    setStudySets(prev => prev.map(set => {
      if (set.id !== setId) return set;
      return {
        ...set,
        quizQuestions: [...set.quizQuestions, newQuestion],
      };
    }));
  }, []);

  const startStudySession = useCallback((setId: string, type: StudySession['type']) => {
    const session: StudySession = {
      id: generateId(),
      setId,
      type,
      startedAt: new Date(),
    };
    setStudySessions(prev => [session, ...prev]);
    return session.id;
  }, []);

  const endStudySession = useCallback((sessionId: string, data: Partial<StudySession>) => {
    setStudySessions(prev => prev.map(session => {
      if (session.id !== sessionId) return session;
      return { ...session, ...data, endedAt: new Date() };
    }));
    
    // Update user progress
    setUserProgress(prev => {
      const today = new Date().toDateString();
      const lastStudy = prev.lastStudyDate?.toDateString();
      let newStreak = prev.currentStreak;
      
      if (lastStudy !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        if (lastStudy === yesterday.toDateString()) {
          newStreak = prev.currentStreak + 1;
        } else {
          newStreak = 1;
        }
      }
      
      return {
        ...prev,
        totalStudySessions: prev.totalStudySessions + 1,
        weeklyProgress: Math.min(prev.weeklyProgress + 1, prev.weeklyGoal),
        currentStreak: newStreak,
        longestStreak: Math.max(newStreak, prev.longestStreak),
        lastStudyDate: new Date(),
        masteryScore: Math.min(prev.masteryScore + (data.score || 0) / 100, 100),
      };
    });
  }, []);

  const addNote = useCallback((title: string, content: string, setId: string) => {
    const newNote: Note = {
      id: generateId(),
      title,
      content,
      setId,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setNotes(prev => [newNote, ...prev]);
  }, []);

  const updateNote = useCallback((id: string, updates: Partial<Note>) => {
    setNotes(prev => prev.map(note =>
      note.id === id ? { ...note, ...updates, updatedAt: new Date() } : note
    ));
  }, []);

  const deleteNote = useCallback((id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
  }, []);

  const addGameScore = useCallback((score: Omit<GameScore, 'completedAt'>) => {
    const newScore: GameScore = {
      ...score,
      completedAt: new Date(),
    };
    setGameScores(prev => [newScore, ...prev]);
  }, []);

  const addTutorMessage = useCallback((setId: string, message: Omit<TutorMessage, 'id' | 'timestamp'>) => {
    const newMessage: TutorMessage = {
      ...message,
      id: generateId(),
      timestamp: new Date(),
    };
    setTutorMessages(prev => ({
      ...prev,
      [setId]: [...(prev[setId] || []), newMessage],
    }));
  }, []);

  const createStudyPlan = useCallback((plan: Omit<StudyPlan, 'id' | 'completed'>) => {
    const newPlan: StudyPlan = {
      ...plan,
      id: generateId(),
      completed: false,
    };
    setStudyPlans(prev => [...prev, newPlan]);
  }, []);

  const completeStudyPlan = useCallback((id: string) => {
    setStudyPlans(prev => prev.map(plan =>
      plan.id === id ? { ...plan, completed: true } : plan
    ));
  }, []);

  const resetWeeklyProgress = useCallback(() => {
    setUserProgress(prev => ({ ...prev, weeklyProgress: 0 }));
  }, []);

  const setWeeklyGoal = useCallback((goal: number) => {
    setUserProgress(prev => ({
      ...prev,
      weeklyGoal: Math.max(1, Math.min(200, goal)),
    }));
  }, []);

  const rateFlashcardSrs = useCallback(
    (setId: string, flashcardId: string, rating: SrsRating) => {
      setStudySets((prev) =>
        prev.map((set) => {
          if (set.id !== setId) return set;
          return {
            ...set,
            flashcards: set.flashcards.map((fc) => {
              if (fc.id !== flashcardId) return fc;
              const next = scheduleReview(
                {
                  easeFactor: fc.easeFactor,
                  intervalDays: fc.intervalDays,
                  repetitions: fc.repetitions,
                },
                rating
              );
              const gotIt = rating === 'good' || rating === 'easy';
              return {
                ...fc,
                easeFactor: next.easeFactor,
                intervalDays: next.intervalDays,
                repetitions: next.repetitions,
                nextReview: next.nextReview,
                lastReviewed: new Date(),
                timesReviewed: fc.timesReviewed + 1,
                timesCorrect: fc.timesCorrect + (gotIt ? 1 : 0),
              };
            }),
          };
        })
      );
    },
    []
  );

  const recordPomodoroComplete = useCallback(() => {
    setUserProgress((prev) => ({
      ...prev,
      pomodoroSessionsCompleted: (prev.pomodoroSessionsCompleted ?? 0) + 1,
      totalStudyTime: prev.totalStudyTime + 25,
    }));
  }, []);

  const exportBackup = useCallback(() => {
    const data = {
      version: 1,
      exportedAt: new Date().toISOString(),
      studySets,
      studySessions,
      notes,
      gameScores,
      tutorMessages,
      studyPlans,
      userProgress,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vantage-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [studySets, studySessions, notes, gameScores, tutorMessages, studyPlans, userProgress]);

  const importBackup = useCallback(
    (jsonText: string) => {
      const parsed = JSON.parse(jsonText) as Record<string, unknown>;
      if (!parsed || typeof parsed !== 'object') throw new Error('Invalid file');
      const p = parsed as {
        studySets?: StudySet[];
        studySessions?: StudySession[];
        notes?: Note[];
        gameScores?: GameScore[];
        tutorMessages?: Record<string, TutorMessage[]>;
        studyPlans?: StudyPlan[];
        userProgress?: UserProgress;
      };
      const payload: Parameters<typeof hydrateState>[0] = {
        studySets: p.studySets,
        studySessions: p.studySessions,
        notes: p.notes,
        gameScores: p.gameScores,
        tutorMessages: p.tutorMessages,
        studyPlans: p.studyPlans,
        userProgress: p.userProgress,
      };
      hydrateState(payload);
      if (p.studySets) setStudySets(p.studySets);
      if (p.studySessions) setStudySessions(p.studySessions);
      if (p.notes) setNotes(p.notes);
      if (p.gameScores) setGameScores(p.gameScores);
      if (p.tutorMessages) setTutorMessages(p.tutorMessages);
      if (p.studyPlans) setStudyPlans(p.studyPlans);
      if (p.userProgress) {
        setUserProgress((prev) => ({
          ...prev,
          ...p.userProgress,
          pomodoroSessionsCompleted:
            p.userProgress!.pomodoroSessionsCompleted ?? prev.pomodoroSessionsCompleted ?? 0,
        }));
      }
    },
    []
  );

  return {
    studySets,
    studySessions,
    notes,
    gameScores,
    tutorMessages,
    studyPlans,
    userProgress,
    isLoaded,
    createStudySet,
    deleteStudySet,
    updateFlashcard,
    addFlashcard,
    addQuizQuestion,
    startStudySession,
    endStudySession,
    addNote,
    updateNote,
    deleteNote,
    addGameScore,
    addTutorMessage,
    createStudyPlan,
    completeStudyPlan,
    resetWeeklyProgress,
    setWeeklyGoal,
    rateFlashcardSrs,
    recordPomodoroComplete,
    exportBackup,
    importBackup,
  };
};