import { useState } from 'react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from './AuthProvider';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Sparkles } from 'lucide-react';
import { CreatorCredit } from '@/components/CreatorCredit';

export function AuthPanel() {
  const { loading, signIn, signUp } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const submitSignUp = async () => {
    if (!email.trim() || password.length < 6) {
      toast.error('Use a valid email and a password (6+ characters).');
      return;
    }
    const res = await signUp(email.trim(), password);
    if (!res.ok) {
      toast.error(res.message);
      return;
    }
    toast.success('Account created. If confirmation is enabled, check your email.');
  };

  const submitSignIn = async () => {
    if (!email.trim() || password.length < 1) {
      toast.error('Enter your email and password.');
      return;
    }
    const res = await signIn(email.trim(), password);
    if (!res.ok) {
      toast.error(res.message);
      return;
    }
    toast.success('Welcome back!');
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center px-4 py-10">
      <div className="bg-layer bg-layer-mesh absolute inset-0 -z-10" aria-hidden />
      <div className="w-full max-w-md space-y-5 relative z-10">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#B8B2F7]" />
            <span className="font-bold tracking-tight">VANTAGE</span>
          </div>
          <ThemeToggle />
        </div>

        <div className="glass-card p-6 space-y-4 shadow-[0_24px_80px_rgba(0,0,0,0.45)] border-[#B8B2F7]/15">
          <div>
            <h1 className="text-2xl font-bold mb-1">Sign in to start</h1>
            <p className="text-sm text-[#A7ACB8]">
              Your study decks, progress, and plans are saved per account.
            </p>
          </div>

          <Tabs defaultValue="signin">
            <TabsList className="grid grid-cols-2 w-full bg-white/5 border border-white/10 rounded-xl p-1">
              <TabsTrigger value="signin">Sign in</TabsTrigger>
              <TabsTrigger value="signup">Sign up</TabsTrigger>
            </TabsList>

            <TabsContent value="signin" className="mt-4 space-y-3">
              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                className="bg-white/5 border-white/10 text-[#F4F6FB]"
                type="email"
                autoComplete="email"
              />
              <Input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="bg-white/5 border-white/10 text-[#F4F6FB]"
                type="password"
                autoComplete="current-password"
              />
              <Button type="button" className="btn-accent w-full" disabled={loading} onClick={submitSignIn}>
                {loading ? 'Loading...' : 'Sign in'}
              </Button>
            </TabsContent>

            <TabsContent value="signup" className="mt-4 space-y-3">
              <Input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                className="bg-white/5 border-white/10 text-[#F4F6FB]"
                type="email"
                autoComplete="email"
              />
              <Input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password (6+ chars)"
                className="bg-white/5 border-white/10 text-[#F4F6FB]"
                type="password"
                autoComplete="new-password"
              />
              <Button type="button" className="btn-accent w-full" disabled={loading} onClick={submitSignUp}>
                {loading ? 'Loading...' : 'Create account'}
              </Button>
              <p className="text-xs text-[#A7ACB8] leading-relaxed">
                If your Supabase project requires email confirmation, you’ll need to verify via email before signing in.
              </p>
            </TabsContent>
          </Tabs>
        </div>

        <CreatorCredit variant="featured" />
        <p className="text-xs text-[#A7ACB8] text-center">
          You can remove this sign-in requirement later if you want local-only mode.
        </p>
      </div>
    </div>
  );
}

