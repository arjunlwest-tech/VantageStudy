import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

if (!supabaseUrl || !supabaseAnonKey) {
  // This app can still build, but auth will fail until env vars are set.
  // eslint-disable-next-line no-console
  console.warn(
    '[Auth] Missing VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY. Create a Supabase project and set these env vars.'
  );
}

export const supabase = createClient(
  supabaseUrl ?? 'https://example.supabase.co',
  supabaseAnonKey ?? 'public-anon-key'
);

