export interface StudySet {
  id: string;
  name: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  flashcards: Flashcard[];
  quizQuestions: QuizQuestion[];
  color: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  difficulty: 'easy' | 'medium' | 'hard';
  lastReviewed?: Date;
  nextReview?: Date;
  timesReviewed: number;
  timesCorrect: number;
  /** Spaced repetition (SM-2 style) */
  easeFactor?: number;
  intervalDays?: number;
  repetitions?: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  type: 'multiple_choice' | 'fill_blank' | 'explanation';
}

export interface StudySession {
  id: string;
  setId: string;
  type: 'flashcards' | 'quiz' | 'tutor' | 'game';
  startedAt: Date;
  endedAt?: Date;
  score?: number;
  cardsReviewed?: number;
  correctAnswers?: number;
  totalQuestions?: number;
}

export interface UserProgress {
  totalStudySets: number;
  totalFlashcards: number;
  totalStudySessions: number;
  weeklyGoal: number;
  weeklyProgress: number;
  currentStreak: number;
  longestStreak: number;
  totalStudyTime: number;
  masteryScore: number;
  lastStudyDate?: Date;
  pomodoroSessionsCompleted?: number;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  setId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface GameScore {
  gameType: 'matching' | 'speedrun' | 'memory';
  setId: string;
  score: number;
  timeElapsed: number;
  completedAt: Date;
}

export interface TutorMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface StudyPlan {
  id: string;
  title: string;
  description: string;
  setIds: string[];
  targetDate: Date;
  dailyGoal: number;
  completed: boolean;
}