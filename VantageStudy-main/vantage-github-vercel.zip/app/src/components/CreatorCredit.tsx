import { useId } from 'react';
import { cn } from '@/lib/utils';
import { ExternalLink } from 'lucide-react';

const INSTAGRAM_URL = 'https://www.instagram.com/arjunlwest/';

function InstagramGlyph({ className }: { className?: string }) {
  const rawId = useId().replace(/:/g, '');
  const gradId = `ig-grad-${rawId}`;
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden
      className={cn('shrink-0', className)}
    >
      <linearGradient id={gradId} x1="0%" y1="100%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#f09433" />
        <stop offset="50%" stopColor="#e6683c" />
        <stop offset="100%" stopColor="#bc1888" />
      </linearGradient>
      <path
        fill={`url(#${gradId})`}
        d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44 1.439-.645 1.439-1.44-.644-1.44-1.439-1.44z"
      />
    </svg>
  );
}

export type CreatorCreditVariant = 'compact' | 'featured' | 'sidebar';

type CreatorCreditProps = {
  className?: string;
  variant?: CreatorCreditVariant;
};

export function CreatorCredit({ className, variant = 'compact' }: CreatorCreditProps) {
  if (variant === 'featured') {
    return (
      <a
        href={INSTAGRAM_URL}
        target="_blank"
        rel="noopener noreferrer"
        className={cn(
          'group relative flex items-start gap-4 rounded-2xl border border-white/10 bg-gradient-to-br from-white/[0.07] to-white/[0.02] p-4',
          'shadow-[0_16px_48px_rgba(0,0,0,0.35)] transition-all duration-300',
          'hover:border-[#B8B2F7]/35 hover:shadow-[0_20px_60px_rgba(184,178,247,0.12)]',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#B8B2F7]/50 focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg-primary)]',
          className
        )}
      >
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/10 transition-transform duration-300 group-hover:scale-105">
          <InstagramGlyph className="h-6 w-6" />
        </div>
        <div className="min-w-0 flex-1 space-y-1">
          <p className="text-sm font-semibold text-[#F4F6FB] tracking-tight">
            Made by{' '}
            <span className="bg-gradient-to-r from-[#B8B2F7] via-[#7DD3FC] to-[#86EFAC] bg-clip-text text-transparent">
              @arjunlwest
            </span>
          </p>
          <p className="text-xs text-[#A7ACB8] leading-relaxed">
            Follow on Instagram for updates, drops, and behind-the-scenes.
          </p>
          <span className="inline-flex items-center gap-1 text-xs font-medium text-[#B8B2F7] group-hover:gap-2 transition-all">
            Open profile
            <ExternalLink className="h-3.5 w-3.5 opacity-80" />
          </span>
        </div>
      </a>
    );
  }

  if (variant === 'sidebar') {
    return (
      <a
        href={INSTAGRAM_URL}
        target="_blank"
        rel="noopener noreferrer"
        className={cn(
          'flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2.5',
          'text-[11px] leading-snug text-[#A7ACB8] transition-all duration-200',
          'hover:border-[#B8B2F7]/30 hover:bg-[#B8B2F7]/[0.06] hover:text-[#F4F6FB]',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#B8B2F7]/40',
          className
        )}
      >
        <InstagramGlyph className="h-4 w-4" />
        <span>
          <span className="text-[#F4F6FB]/90 font-medium">@arjunlwest</span>
          <span className="block text-[10px] text-[#A7ACB8]/90">Instagram</span>
        </span>
      </a>
    );
  }

  /* compact — nav / mobile */
  return (
    <a
      href={INSTAGRAM_URL}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        'inline-flex max-w-full items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5',
        'text-[11px] text-[#A7ACB8] backdrop-blur-sm transition-all duration-200',
        'hover:border-[#B8B2F7]/35 hover:bg-[#B8B2F7]/[0.08] hover:text-[#F4F6FB]',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#B8B2F7]/45',
        className
      )}
    >
      <InstagramGlyph className="h-3.5 w-3.5" />
      <span className="truncate">
        <span className="font-medium text-[#F4F6FB]/95">@arjunlwest</span>
        <span className="text-[#A7ACB8]"> · Instagram</span>
      </span>
    </a>
  );
}
