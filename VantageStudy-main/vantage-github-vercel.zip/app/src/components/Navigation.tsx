import { useState, useEffect } from 'react';
import { Menu, X, Sparkles } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useStudyStore } from '@/hooks/useStudyStore';
import { toast } from 'sonner';
import { ThemeToggle } from '@/components/ThemeToggle';
import { CreatorCredit } from '@/components/CreatorCredit';

const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [newSetName, setNewSetName] = useState('');
  const [newSetContent, setNewSetContent] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { createStudySet } = useStudyStore();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  const handleCreateSet = () => {
    if (!newSetName.trim() || !newSetContent.trim()) {
      toast.error('Please fill in all fields');
      return;
    }
    createStudySet(newSetName, newSetContent);
    setNewSetName('');
    setNewSetContent('');
    setIsDialogOpen(false);
    toast.success('Study set created successfully!');
  };

  const openDashboard = () => {
    window.dispatchEvent(new CustomEvent('open-dashboard'));
    setIsMobileMenuOpen(false);
  };

  const navLinks = [
    { label: 'Dashboard', action: openDashboard },
    { label: 'Tutor', action: () => scrollToSection('tutor') },
    { label: 'Flashcards', action: () => scrollToSection('flashcards') },
    { label: 'Games', action: () => scrollToSection('games') },
    { label: 'Pricing', action: () => scrollToSection('pricing') },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[var(--bg-primary)]/80 backdrop-blur-xl border-b border-white/5'
            : 'bg-transparent'
        }`}
      >
        <div className="w-full px-6 lg:px-12">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <button
              onClick={() => scrollToSection('landing')}
              className="flex items-center gap-2 group"
            >
              <Sparkles className="w-6 h-6 text-[#B8B2F7] group-hover:scale-110 transition-transform" />
              <span className="text-xl font-bold tracking-tight">VANTAGE</span>
            </button>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={link.action}
                  className="text-sm text-[#A7ACB8] hover:text-[#F4F6FB] transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </div>

            {/* CTA Button */}
            <div className="hidden lg:flex items-center gap-3">
              <CreatorCredit
                variant="compact"
                className="hidden lg:inline-flex max-w-[min(220px,28vw)]"
              />
              <ThemeToggle />
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <button className="btn-accent">Get Started</button>
                </DialogTrigger>
                <DialogContent className="glass-card border-[#B8B2F7]/20 max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-bold text-[#F4F6FB]">
                      Create New Study Set
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 mt-4">
                    <div>
                      <label className="text-sm text-[#A7ACB8] mb-2 block">
                        Subject Name
                      </label>
                      <Input
                        value={newSetName}
                        onChange={(e) => setNewSetName(e.target.value)}
                        placeholder="e.g., Organic Chemistry"
                        className="bg-white/5 border-white/10 text-[#F4F6FB] placeholder:text-[#A7ACB8]/50"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-[#A7ACB8] mb-2 block">
                        Your Notes
                      </label>
                      <Textarea
                        value={newSetContent}
                        onChange={(e) => setNewSetContent(e.target.value)}
                        placeholder="Paste your notes, textbook content, or any study material here..."
                        className="bg-white/5 border-white/10 text-[#F4F6FB] placeholder:text-[#A7ACB8]/50 min-h-[200px]"
                      />
                    </div>
                    <Button
                      onClick={handleCreateSet}
                      className="w-full btn-accent"
                    >
                      Create Study Set
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-[var(--bg-primary)]/95 backdrop-blur-xl border-t border-white/5">
            <div className="px-6 py-4 space-y-4">
              <div className="flex justify-end pb-2">
                <ThemeToggle />
              </div>
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={link.action}
                  className="block w-full text-left py-2 text-[#A7ACB8] hover:text-[#F4F6FB] transition-colors"
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => {
                  setIsDialogOpen(true);
                  setIsMobileMenuOpen(false);
                }}
                className="btn-accent w-full mt-4"
              >
                Get Started
              </button>
              <div className="flex justify-center pt-3 border-t border-white/5">
                <CreatorCredit variant="compact" className="max-w-[min(100%,280px)]" />
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
};

export default Navigation;