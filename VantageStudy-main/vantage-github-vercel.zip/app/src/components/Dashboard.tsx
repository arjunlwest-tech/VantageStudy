import { useState, useRef, useEffect, useMemo } from 'react';
import {
  BookOpen,
  MessageSquare,
  Layers,
  Gamepad2,
  BarChart3,
  Plus,
  Trash2,
  X,
  Mic,
  Volume2,
  RotateCw,
  ChevronLeft,
  ChevronRight,
  CheckCircle,
  Clock,
  Flame,
  Target,
  Sparkles,
  StickyNote,
  ClipboardList,
  Download,
  Upload,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { StudySet, Note, StudyPlan, UserProgress } from '@/types';
import type { SrsRating } from '@/lib/srs';
import { PomodoroTimer } from '@/components/PomodoroTimer';
import { CreatorCredit } from '@/components/CreatorCredit';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStudyStore } from '@/hooks/useStudyStore';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

type View =
  | 'sets'
  | 'tutor'
  | 'flashcards'
  | 'quiz'
  | 'games'
  | 'progress'
  | 'notes'
  | 'plans';

const Dashboard = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentView, setCurrentView] = useState<View>('sets');
  const [selectedSetId, setSelectedSetId] = useState<string | null>(null);
  const [newSetName, setNewSetName] = useState('');
  const [newSetContent, setNewSetContent] = useState('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const {
    studySets,
    userProgress,
    notes,
    studyPlans,
    createStudySet,
    deleteStudySet,
    addNote,
    updateNote,
    deleteNote,
    createStudyPlan,
    completeStudyPlan,
    exportBackup,
    importBackup,
    recordPomodoroComplete,
    setWeeklyGoal,
  } = useStudyStore();

  const backupInputRef = useRef<HTMLInputElement>(null);

  const activeSet = studySets.find(s => s.id === selectedSetId);

  const handleCreateSet = () => {
    if (!newSetName.trim() || !newSetContent.trim()) {
      toast.error('Please fill in all fields');
      return;
    }
    const id = createStudySet(newSetName, newSetContent);
    setNewSetName('');
    setNewSetContent('');
    setIsCreateDialogOpen(false);
    setSelectedSetId(id);
    toast.success('Study set created!');
  };

  const handleDeleteSet = (id: string) => {
    if (confirm('Are you sure you want to delete this study set?')) {
      deleteStudySet(id);
      if (selectedSetId === id) setSelectedSetId(null);
      toast.success('Study set deleted');
    }
  };

  // Listen for dashboard open event
  useEffect(() => {
    const handleOpenDashboard = () => {
      setIsOpen(true);
      setCurrentView('sets');
    };
    window.addEventListener('open-dashboard', handleOpenDashboard);
    return () => window.removeEventListener('open-dashboard', handleOpenDashboard);
  }, []);

  if (!isOpen) return null;

  return (
    <div
      id="dashboard"
      className="fixed inset-0 z-[200] bg-[var(--bg-primary)]"
    >
      {/* Dashboard Header */}
      <div className="h-16 border-b border-white/5 flex items-center justify-between px-4 sm:px-6 gap-3 flex-wrap">
        <div className="flex items-center gap-4 min-w-0">
          <button
            onClick={() => setIsOpen(false)}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 min-w-0">
            <Sparkles className="w-5 h-5 text-[#B8B2F7] shrink-0" />
            <span className="font-bold truncate">Dashboard</span>
          </div>
        </div>
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap justify-end">
          <PomodoroTimer
            compact
            onWorkComplete={() => {
              recordPomodoroComplete();
              toast.success('Focus round complete — take your break.');
            }}
          />
          <button
            type="button"
            onClick={() => setIsCreateDialogOpen(true)}
            className="btn-accent flex items-center gap-2 text-sm py-2 px-4"
          >
            <Plus className="w-4 h-4" />
            New Set
          </button>
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="flex h-[calc(100vh-64px)]">
        {/* Sidebar */}
        <div className="w-64 border-r border-white/5 p-4 hidden lg:block">
          <nav className="space-y-2">
            <SidebarButton
              icon={BookOpen}
              label="Study Sets"
              active={currentView === 'sets'}
              onClick={() => setCurrentView('sets')}
            />
            <SidebarButton
              icon={MessageSquare}
              label="AI Tutor"
              active={currentView === 'tutor'}
              onClick={() => selectedSetId ? setCurrentView('tutor') : toast.info('Select a study set first')}
              disabled={!selectedSetId}
            />
            <SidebarButton
              icon={Layers}
              label="Flashcards"
              active={currentView === 'flashcards'}
              onClick={() => selectedSetId ? setCurrentView('flashcards') : toast.info('Select a study set first')}
              disabled={!selectedSetId}
            />
            <SidebarButton
              icon={Target}
              label="Quiz"
              active={currentView === 'quiz'}
              onClick={() => selectedSetId ? setCurrentView('quiz') : toast.info('Select a study set first')}
              disabled={!selectedSetId}
            />
            <SidebarButton
              icon={Gamepad2}
              label="Games"
              active={currentView === 'games'}
              onClick={() => selectedSetId ? setCurrentView('games') : toast.info('Select a study set first')}
              disabled={!selectedSetId}
            />
            <SidebarButton
              icon={BarChart3}
              label="Progress"
              active={currentView === 'progress'}
              onClick={() => setCurrentView('progress')}
            />
            <SidebarButton
              icon={StickyNote}
              label="Notes"
              active={currentView === 'notes'}
              onClick={() =>
                selectedSetId
                  ? setCurrentView('notes')
                  : toast.info('Select a study set first')
              }
              disabled={!selectedSetId}
            />
            <SidebarButton
              icon={ClipboardList}
              label="Study plans"
              active={currentView === 'plans'}
              onClick={() => setCurrentView('plans')}
            />
          </nav>

          <div className="mt-6 space-y-2">
            <button
              type="button"
              onClick={() => exportBackup()}
              className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm text-[#A7ACB8] hover:bg-white/5 hover:text-[#F4F6FB] transition-colors"
            >
              <Download className="w-4 h-4" />
              Export backup
            </button>
            <button
              type="button"
              onClick={() => backupInputRef.current?.click()}
              className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm text-[#A7ACB8] hover:bg-white/5 hover:text-[#F4F6FB] transition-colors"
            >
              <Upload className="w-4 h-4" />
              Import backup
            </button>
            <input
              ref={backupInputRef}
              type="file"
              accept="application/json,.json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const reader = new FileReader();
                reader.onload = () => {
                  try {
                    importBackup(String(reader.result));
                    toast.success('Backup restored successfully.');
                  } catch {
                    toast.error('Could not read that file. Use a Vantage JSON export.');
                  }
                  e.target.value = '';
                };
                reader.readAsText(f);
              }}
            />
          </div>

          {/* Quick Stats */}
          <div className="mt-8 p-4 glass-card">
            <h4 className="text-sm font-medium mb-3 text-[#A7ACB8]">Quick Stats</h4>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#A7ACB8]">Sets</span>
                <span className="font-medium">{studySets.length}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#A7ACB8]">Streak</span>
                <span className="font-medium flex items-center gap-1">
                  <Flame className="w-3 h-3 text-orange-400" />
                  {userProgress.currentStreak || 0} days
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#A7ACB8]">Weekly</span>
                <span className="font-medium">
                  {userProgress.weeklyProgress}/{userProgress.weeklyGoal}
                </span>
              </div>
            </div>
          </div>

          <CreatorCredit variant="sidebar" className="mt-6" />
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto p-6">
          {currentView === 'sets' && (
            <StudySetsView
              studySets={studySets}
              selectedSetId={selectedSetId}
              onSelectSet={setSelectedSetId}
              onDeleteSet={handleDeleteSet}
              onCreateSet={() => setIsCreateDialogOpen(true)}
            />
          )}
          {currentView === 'tutor' && activeSet && (
            <TutorView studySet={activeSet} />
          )}
          {currentView === 'flashcards' && activeSet && (
            <FlashcardsView studySet={activeSet} />
          )}
          {currentView === 'quiz' && activeSet && (
            <QuizView studySet={activeSet} />
          )}
          {currentView === 'games' && activeSet && (
            <GamesView studySet={activeSet} />
          )}
          {currentView === 'progress' && (
            <ProgressView
              userProgress={userProgress}
              studySets={studySets}
              setWeeklyGoal={setWeeklyGoal}
            />
          )}
          {currentView === 'notes' && activeSet && (
            <NotesView
              studySet={activeSet}
              notes={notes.filter((n) => n.setId === activeSet.id)}
              onAdd={addNote}
              onUpdate={updateNote}
              onDelete={deleteNote}
            />
          )}
          {currentView === 'plans' && (
            <PlansView
              studyPlans={studyPlans}
              studySets={studySets}
              onCreate={createStudyPlan}
              onComplete={completeStudyPlan}
            />
          )}
        </div>
      </div>

      {/* Create Set Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="glass-card border-[#B8B2F7]/20 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-[#F4F6FB]">
              Create New Study Set
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <label className="text-sm text-[#A7ACB8] mb-2 block">
                Subject Name
              </label>
              <Input
                value={newSetName}
                onChange={(e) => setNewSetName(e.target.value)}
                placeholder="e.g., Organic Chemistry"
                className="bg-white/5 border-white/10 text-[#F4F6FB] placeholder:text-[#A7ACB8]/50"
              />
            </div>
            <div>
              <label className="text-sm text-[#A7ACB8] mb-2 block">
                Your Notes
              </label>
              <Textarea
                value={newSetContent}
                onChange={(e) => setNewSetContent(e.target.value)}
                placeholder="Paste your notes, textbook content, or any study material here..."
                className="bg-white/5 border-white/10 text-[#F4F6FB] placeholder:text-[#A7ACB8]/50 min-h-[200px]"
              />
            </div>
            <Button onClick={handleCreateSet} className="w-full btn-accent">
              Create Study Set
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Sidebar Button Component
const SidebarButton = ({
  icon: Icon,
  label,
  active,
  onClick,
  disabled,
}: {
  icon: React.ElementType;
  label: string;
  active: boolean;
  onClick: () => void;
  disabled?: boolean;
}) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
      active
        ? 'bg-[#B8B2F7]/20 text-[#B8B2F7]'
        : 'text-[#A7ACB8] hover:bg-white/5 hover:text-[#F4F6FB]'
    } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
  >
    <Icon className="w-4 h-4" />
    {label}
  </button>
);

// Study Sets View
const StudySetsView = ({
  studySets,
  selectedSetId,
  onSelectSet,
  onDeleteSet,
  onCreateSet,
}: {
  studySets: any[];
  selectedSetId: string | null;
  onSelectSet: (id: string) => void;
  onDeleteSet: (id: string) => void;
  onCreateSet: () => void;
}) => {
  if (studySets.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <div className="w-20 h-20 rounded-2xl bg-[#B8B2F7]/20 flex items-center justify-center mb-6">
          <BookOpen className="w-10 h-10 text-[#B8B2F7]" />
        </div>
        <h3 className="text-2xl font-bold mb-2">No study sets yet</h3>
        <p className="text-[#A7ACB8] mb-6 max-w-md">
          Create your first study set to get started with flashcards, quizzes, and AI tutoring.
        </p>
        <button onClick={onCreateSet} className="btn-accent flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Create Your First Set
        </button>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Your Study Sets</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {studySets.map((set) => (
          <div
            key={set.id}
            onClick={() => onSelectSet(set.id)}
            className={`glass-card p-5 cursor-pointer transition-all ${
              selectedSetId === set.id
                ? 'border-[#B8B2F7]/50 bg-[#B8B2F7]/10'
                : 'hover:-translate-y-1'
            }`}
          >
            <div className="flex items-start justify-between mb-3">
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: `${set.color}20` }}
              >
                <BookOpen className="w-5 h-5" style={{ color: set.color }} />
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteSet(set.id);
                }}
                className="p-1 hover:bg-red-500/20 rounded transition-colors"
              >
                <Trash2 className="w-4 h-4 text-red-400" />
              </button>
            </div>
            <h3 className="font-semibold mb-1">{set.name}</h3>
            <p className="text-sm text-[#A7ACB8]">
              {set.flashcards.length} flashcards • {set.quizQuestions.length} quiz questions
            </p>
            {selectedSetId === set.id && (
              <div className="mt-3 flex items-center gap-2 text-sm text-[#B8B2F7]">
                <CheckCircle className="w-4 h-4" />
                Selected
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const findRelevantSnippet = (userText: string, content: string): string | null => {
  const words = userText
    .toLowerCase()
    .split(/\W+/)
    .filter((w) => w.length > 3);
  const chunks = content.split(/[.!?\n]+/).filter((c) => c.trim().length > 24);
  for (const chunk of chunks) {
    const lower = chunk.toLowerCase();
    if (words.some((w) => lower.includes(w))) return chunk.trim();
  }
  return null;
};

type TutorChatMessage = { role: 'user' | 'assistant'; content: string };

// Tutor View
const TutorView = ({ studySet }: { studySet: StudySet }) => {
  const [messages, setMessages] = useState<TutorChatMessage[]>([
    {
      role: 'assistant',
      content: `Hi! I'm your study coach for **${studySet.name}**. Ask me to explain terms, walk through a concept, or quiz you — I'll stay anchored to the notes you pasted.`,
    },
  ]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const speak = (text: string) => {
    const plain = text.replace(/\*\*/g, '');
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(plain);
      utterance.pitch = 1.05;
      utterance.rate = 1;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      speechSynthesis.speak(utterance);
    }
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }]);
    setInput('');
    setIsListening(true);

    setTimeout(() => {
      const snippet = findRelevantSnippet(userMessage, studySet.content);
      const base = snippet
        ? `From your notes: "${snippet.slice(0, 280)}${snippet.length > 280 ? '…' : ''}"\n\n`
        : '';
      const followUps = [
        `${base}Connect this to the bigger picture in **${studySet.name}**: summarize the main idea in one sentence, then list two details you'd put on a flashcard.`,
        `${base}Try active recall: close your notes and explain this concept aloud as if teaching a friend. I can prompt you with checks: "What changes if…?"`,
        `${base}Exam-style tip: identify the **trigger words** in your question, then map each back to a definition or step from your material.`,
      ];
      const response = followUps[Math.floor(Math.random() * followUps.length)];
      setMessages((prev) => [...prev, { role: 'assistant', content: response }]);
      speak(response);
      setIsListening(false);
    }, 900);
  };

  const handleVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error('Voice recognition not supported');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (e: any) => {
      setInput(e.results[0][0].transcript);
      setTimeout(handleSend, 100);
    };
    recognition.start();
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold">AI Tutor</h2>
          <p className="text-sm text-[#A7ACB8]">Studying: {studySet.name}</p>
        </div>
        <div className="flex items-center gap-2">
          {isSpeaking && <Volume2 className="w-5 h-5 text-[#B8B2F7] animate-pulse" />}
        </div>
      </div>

      <div className="flex-1 glass-card overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] p-4 rounded-2xl ${
                  msg.role === 'user'
                    ? 'bg-[#B8B2F7] text-[#07080B] rounded-br-md'
                    : 'bg-white/10 text-[#F4F6FB] rounded-bl-md'
                }`}
              >
                {msg.content}
              </div>
            </div>
          ))}
          {isListening && (
            <div className="flex justify-start">
              <div className="bg-white/10 p-4 rounded-2xl rounded-bl-md">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-[#B8B2F7] rounded-full animate-bounce" />
                  <span className="w-2 h-2 bg-[#B8B2F7] rounded-full animate-bounce [animation-delay:0.1s]" />
                  <span className="w-2 h-2 bg-[#B8B2F7] rounded-full animate-bounce [animation-delay:0.2s]" />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t border-white/10">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask anything..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-[#F4F6FB] placeholder:text-[#A7ACB8]/50"
            />
            <button
              onClick={handleSend}
              className="px-4 py-3 bg-[#B8B2F7] rounded-xl text-[#07080B] font-medium hover:scale-105 transition-transform"
            >
              Send
            </button>
            <button
              onClick={handleVoice}
              disabled={isListening}
              className={`px-4 py-3 rounded-xl transition-all ${
                isListening ? 'bg-red-500' : 'bg-white/10 hover:bg-white/20'
              }`}
            >
              <Mic className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Flashcards View
const FlashcardsView = ({ studySet }: { studySet: StudySet }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newFront, setNewFront] = useState('');
  const [newBack, setNewBack] = useState('');
  const [learnActiveId, setLearnActiveId] = useState<string | null>(null);
  const { addFlashcard, rateFlashcardSrs } = useStudyStore();

  const flashcards = studySet.flashcards;

  const dueCards = useMemo(() => {
    const now = Date.now();
    return flashcards.filter(
      (fc) =>
        !fc.nextReview || new Date(fc.nextReview).getTime() <= now
    );
  }, [flashcards]);

  useEffect(() => {
    if (!dueCards.length) {
      setLearnActiveId(null);
      return;
    }
    if (!learnActiveId || !dueCards.some((c) => c.id === learnActiveId)) {
      setLearnActiveId(dueCards[0].id);
    }
  }, [dueCards, learnActiveId]);

  const learnCard = dueCards.find((c) => c.id === learnActiveId) ?? dueCards[0];

  const nextCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % flashcards.length);
    }, 200);
  };

  const prevCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + flashcards.length) % flashcards.length);
    }, 200);
  };

  const handleAdd = () => {
    if (!newFront.trim() || !newBack.trim()) {
      toast.error('Please fill in both sides');
      return;
    }
    addFlashcard(studySet.id, newFront, newBack);
    setNewFront('');
    setNewBack('');
    setShowAddDialog(false);
    toast.success('Flashcard added!');
  };

  const rateLearn = (rating: SrsRating) => {
    if (!learnCard) return;
    rateFlashcardSrs(studySet.id, learnCard.id, rating);
    setIsFlipped(false);
    setLearnActiveId(null);
    toast.success('Scheduled — keep going!');
  };

  const addCardDialog = (
    <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
      <DialogContent className="glass-card border-[#B8B2F7]/20">
        <DialogHeader>
          <DialogTitle>Add Flashcard</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-4">
          <div>
            <label className="text-sm text-[#A7ACB8] mb-2 block">Front (Question)</label>
            <Textarea
              value={newFront}
              onChange={(e) => setNewFront(e.target.value)}
              placeholder="Enter the question..."
              className="bg-white/5 border-white/10 text-[#F4F6FB]"
            />
          </div>
          <div>
            <label className="text-sm text-[#A7ACB8] mb-2 block">Back (Answer)</label>
            <Textarea
              value={newBack}
              onChange={(e) => setNewBack(e.target.value)}
              placeholder="Enter the answer..."
              className="bg-white/5 border-white/10 text-[#F4F6FB]"
            />
          </div>
          <Button onClick={handleAdd} className="w-full btn-accent">
            Add Flashcard
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );

  if (flashcards.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <Layers className="w-16 h-16 text-[#A7ACB8] mb-4" />
        <h3 className="text-xl font-bold mb-2">No flashcards yet</h3>
        <p className="text-[#A7ACB8] mb-4">Add your first flashcard to start studying.</p>
        <button type="button" onClick={() => setShowAddDialog(true)} className="btn-accent">
          Add Flashcard
        </button>
        {addCardDialog}
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <Tabs defaultValue="browse" className="flex-1 flex flex-col min-h-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <TabsList className="bg-white/5 border border-white/10 rounded-xl p-1 w-fit">
            <TabsTrigger value="browse" className="rounded-lg data-[state=active]:bg-[#B8B2F7]/25">
              Browse
            </TabsTrigger>
            <TabsTrigger value="learn" className="rounded-lg data-[state=active]:bg-[#B8B2F7]/25">
              Learn (SRS)
            </TabsTrigger>
          </TabsList>
          <button
            type="button"
            onClick={() => setShowAddDialog(true)}
            className="btn-secondary text-sm self-start sm:self-auto"
          >
            <Plus className="w-4 h-4 inline mr-1" />
            Add Card
          </button>
        </div>

        <TabsContent value="browse" className="flex-1 flex flex-col mt-0 min-h-0">
          <div className="mb-4">
            <h2 className="text-2xl font-bold">Flashcards</h2>
            <p className="text-sm text-[#A7ACB8]">
              Card {currentIndex + 1} of {flashcards.length}
            </p>
          </div>
          <div className="flex-1 flex items-center justify-center">
            <div
              className="flashcard w-full max-w-xl cursor-pointer"
              onClick={() => setIsFlipped(!isFlipped)}
              style={{ perspective: '1000px' }}
            >
              <div
                className={`flashcard-inner ${isFlipped ? 'flipped' : ''}`}
                style={{ transformStyle: 'preserve-3d', height: '300px' }}
              >
                <div className="flashcard-front">
                  <div className="text-center">
                    <p className="text-lg font-medium mb-4">{flashcards[currentIndex]?.front}</p>
                    <span className="text-sm text-[#A7ACB8]">Click to flip</span>
                  </div>
                </div>
                <div className="flashcard-back">
                  <p className="text-base leading-relaxed">{flashcards[currentIndex]?.back}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-center gap-4 mt-6">
            <button
              type="button"
              onClick={prevCard}
              className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              type="button"
              onClick={() => setIsFlipped(!isFlipped)}
              className="w-14 h-14 rounded-full bg-[#B8B2F7] flex items-center justify-center hover:scale-105 transition-transform"
            >
              <RotateCw className="w-6 h-6 text-[#07080B]" />
            </button>
            <button
              type="button"
              onClick={nextCard}
              className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </TabsContent>

        <TabsContent value="learn" className="flex-1 flex flex-col mt-0">
          <div className="mb-4">
            <h2 className="text-2xl font-bold">Spaced repetition</h2>
            <p className="text-sm text-[#A7ACB8]">
              {dueCards.length} card{dueCards.length !== 1 ? 's' : ''} due now · SM-2 style scheduling
            </p>
          </div>
          {!learnCard ? (
            <div className="flex-1 flex flex-col items-center justify-center glass-card p-8 text-center">
              <CheckCircle className="w-14 h-14 text-green-400 mb-4" />
              <p className="font-semibold text-lg mb-2">You&apos;re caught up</p>
              <p className="text-[#A7ACB8] text-sm max-w-md">
                Nothing is due right now. Check back later or use Browse mode to free-study any card.
              </p>
            </div>
          ) : (
            <>
              <div className="flex-1 flex items-center justify-center">
                <div
                  className="flashcard w-full max-w-xl cursor-pointer"
                  onClick={() => setIsFlipped(!isFlipped)}
                  style={{ perspective: '1000px' }}
                >
                  <div
                    className={`flashcard-inner ${isFlipped ? 'flipped' : ''}`}
                    style={{ transformStyle: 'preserve-3d', height: '300px' }}
                  >
                    <div className="flashcard-front">
                      <div className="text-center">
                        <p className="text-lg font-medium mb-4">{learnCard.front}</p>
                        <span className="text-sm text-[#A7ACB8]">Flip to answer, then rate recall</span>
                      </div>
                    </div>
                    <div className="flashcard-back">
                      <p className="text-base leading-relaxed">{learnCard.back}</p>
                    </div>
                  </div>
                </div>
              </div>
              {isFlipped && (
                <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-2 max-w-xl mx-auto w-full">
                  {(
                    [
                      ['again', 'Again', '10 min'],
                      ['hard', 'Hard', 'shorter'],
                      ['good', 'Good', 'optimal'],
                      ['easy', 'Easy', 'longer'],
                    ] as const
                  ).map(([key, label, hint]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => rateLearn(key)}
                      className="rounded-xl border border-white/10 bg-white/5 py-3 px-2 text-sm font-medium hover:bg-[#B8B2F7]/15 hover:border-[#B8B2F7]/30 transition-colors"
                    >
                      <span className="block">{label}</span>
                      <span className="block text-[10px] text-[#A7ACB8] font-normal mt-0.5">{hint}</span>
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>

      {addCardDialog}
    </div>
  );
};

// Quiz View
const QuizView = ({ studySet }: { studySet: any }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  const questions = studySet.quizQuestions;
  const currentQ = questions[currentIndex];

  const handleSelect = (index: number) => {
    if (showResult) return;
    setSelected(index);
    setShowResult(true);
    if (index === currentQ.correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const nextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setSelected(null);
      setShowResult(false);
    } else {
      setFinished(true);
    }
  };

  const restart = () => {
    setCurrentIndex(0);
    setSelected(null);
    setShowResult(false);
    setScore(0);
    setFinished(false);
  };

  if (questions.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center">
        <Target className="w-16 h-16 text-[#A7ACB8] mb-4" />
        <h3 className="text-xl font-bold mb-2">No quiz questions yet</h3>
        <p className="text-[#A7ACB8]">Add more content to generate quiz questions.</p>
      </div>
    );
  }

  if (finished) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="h-full flex flex-col items-center justify-center">
        <div className="glass-card p-8 text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-[#B8B2F7]/20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-[#B8B2F7]" />
          </div>
          <h3 className="text-2xl font-bold mb-2">Quiz Complete!</h3>
          <p className="text-4xl font-bold text-[#B8B2F7] mb-2">{percentage}%</p>
          <p className="text-[#A7ACB8] mb-6">
            You got {score} out of {questions.length} correct
          </p>
          <button onClick={restart} className="btn-accent">
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Quiz</h2>
          <p className="text-sm text-[#A7ACB8]">
            Question {currentIndex + 1} of {questions.length}
          </p>
        </div>
        <div className="text-sm text-[#A7ACB8]">
          Score: {score}/{currentIndex + (showResult ? 1 : 0)}
        </div>
      </div>

      <div className="glass-card p-6 flex-1">
        <div className="h-1 bg-white/10 rounded-full mb-6">
          <div
            className="h-full bg-[#B8B2F7] rounded-full transition-all"
            style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          />
        </div>

        <h3 className="text-lg font-medium mb-6">{currentQ.question}</h3>

        <div className="space-y-3">
          {currentQ.options.map((option: string, index: number) => (
            <button
              key={index}
              onClick={() => handleSelect(index)}
              disabled={showResult}
              className={`quiz-option w-full text-left flex items-center gap-3 ${
                showResult
                  ? index === currentQ.correctAnswer
                    ? 'correct'
                    : selected === index
                    ? 'incorrect'
                    : ''
                  : selected === index
                  ? 'selected'
                  : ''
              }`}
            >
              <span className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-sm font-medium">
                {String.fromCharCode(65 + index)}
              </span>
              <span className="flex-1">{option}</span>
              {showResult && index === currentQ.correctAnswer && (
                <CheckCircle className="w-5 h-5 text-green-400" />
              )}
            </button>
          ))}
        </div>

        {showResult && (
          <div className="mt-6 p-4 bg-[#B8B2F7]/10 rounded-xl border border-[#B8B2F7]/20">
            <p className="text-sm">
              <strong className="text-[#F4F6FB]">Explanation:</strong>{' '}
              <span className="text-[#A7ACB8]">{currentQ.explanation}</span>
            </p>
          </div>
        )}
      </div>

      {showResult && (
        <div className="mt-4 flex justify-end">
          <button onClick={nextQuestion} className="btn-accent">
            {currentIndex < questions.length - 1 ? 'Next Question' : 'Finish'}
          </button>
        </div>
      )}
    </div>
  );
};

// Games View
const GamesView = ({ studySet }: { studySet: any }) => {
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'finished'>('menu');
  const [cards, setCards] = useState<any[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);

  useEffect(() => {
    if (gameState === 'playing' && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(t => t - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && gameState === 'playing') {
      setGameState('finished');
    }
  }, [timeLeft, gameState]);

  const startGame = () => {
    const flashcards = studySet.flashcards.slice(0, 4);
    const gameCards: any[] = [];
    flashcards.forEach((fc: any, i: number) => {
      gameCards.push({ id: i * 2, content: fc.front.substring(0, 30), pairId: i, type: 'front' });
      gameCards.push({ id: i * 2 + 1, content: fc.back.substring(0, 30), pairId: i, type: 'back' });
    });
    setCards(gameCards.sort(() => Math.random() - 0.5));
    setFlipped([]);
    setMatched([]);
    setScore(0);
    setTimeLeft(60);
    setGameState('playing');
  };

  const handleCardClick = (cardId: number) => {
    if (flipped.length >= 2 || flipped.includes(cardId)) return;
    setFlipped((prev) => [...prev, cardId]);
  };

  useEffect(() => {
    if (flipped.length !== 2) return;
    const card1 = cards.find((c) => c.id === flipped[0]);
    const card2 = cards.find((c) => c.id === flipped[1]);
    if (!card1 || !card2) return;

    if (card1.pairId === card2.pairId) {
      setMatched((prev) => {
        if (prev.includes(card1.pairId)) return prev;
        const next = [...prev, card1.pairId];
        const totalPairs = cards.length / 2;
        if (totalPairs > 0 && next.length >= totalPairs) {
          setTimeout(() => setGameState('finished'), 450);
        }
        return next;
      });
      setScore((s) => s + 100);
      setFlipped([]);
    } else {
      const t = setTimeout(() => setFlipped([]), 900);
      return () => clearTimeout(t);
    }
  }, [flipped, cards]);

  if (gameState === 'menu') {
    return (
      <div className="h-full flex flex-col items-center justify-center">
        <div className="glass-card p-8 text-center max-w-md">
          <Gamepad2 className="w-16 h-16 text-[#B8B2F7] mx-auto mb-6" />
          <h3 className="text-2xl font-bold mb-2">Matching Game</h3>
          <p className="text-[#A7ACB8] mb-6">
            Match terms with their definitions. Beat the clock!
          </p>
          <button onClick={startGame} className="btn-accent">
            Start Game
          </button>
        </div>
      </div>
    );
  }

  if (gameState === 'finished') {
    return (
      <div className="h-full flex flex-col items-center justify-center">
        <div className="glass-card p-8 text-center max-w-md">
          <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-6" />
          <h3 className="text-2xl font-bold mb-2">Game Over!</h3>
          <p className="text-4xl font-bold text-[#B8B2F7] mb-2">{score}</p>
          <p className="text-[#A7ACB8] mb-6">points</p>
          <button onClick={() => setGameState('menu')} className="btn-accent">
            Play Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Matching Game</h2>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-[#A7ACB8]">
            <Clock className="w-4 h-4" />
            <span>{timeLeft}s</span>
          </div>
          <div className="flex items-center gap-2 text-[#B8B2F7]">
            <Target className="w-4 h-4" />
            <span>{score}</span>
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-2xl">
          {cards.map((card) => (
            <button
              key={card.id}
              onClick={() => handleCardClick(card.id)}
              className={`matching-card h-24 ${
                flipped.includes(card.id) || matched.includes(card.pairId)
                  ? matched.includes(card.pairId)
                    ? 'matched'
                    : 'flipped'
                  : ''
              }`}
              disabled={matched.includes(card.pairId)}
            >
              {flipped.includes(card.id) || matched.includes(card.pairId) ? (
                <span className="text-sm">{card.content}</span>
              ) : (
                <span className="text-2xl">?</span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

const NotesView = ({
  studySet,
  notes,
  onAdd,
  onUpdate,
  onDelete,
}: {
  studySet: StudySet;
  notes: Note[];
  onAdd: (title: string, content: string, setId: string) => void;
  onUpdate: (id: string, u: Partial<Note>) => void;
  onDelete: (id: string) => void;
}) => {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const saveNew = () => {
    if (!title.trim() || !body.trim()) {
      toast.error('Add a title and body for your note.');
      return;
    }
    onAdd(title.trim(), body.trim(), studySet.id);
    setTitle('');
    setBody('');
    toast.success('Note saved');
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Notes</h2>
        <p className="text-sm text-[#A7ACB8]">Pinned to {studySet.name}</p>
      </div>
      <div className="glass-card p-5 space-y-3">
        <Input
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="bg-white/5 border-white/10 text-[#F4F6FB]"
        />
        <Textarea
          placeholder="Cues, mnemonics, exam tips…"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          className="bg-white/5 border-white/10 text-[#F4F6FB] min-h-[120px]"
        />
        <Button type="button" onClick={saveNew} className="btn-accent w-full sm:w-auto">
          Add note
        </Button>
      </div>
      <div className="space-y-3">
        {notes.length === 0 ? (
          <p className="text-[#A7ACB8] text-sm">No notes yet for this set.</p>
        ) : (
          notes.map((n) => (
            <div key={n.id} className="glass-card p-4">
              {editingId === n.id ? (
                <div className="space-y-2">
                  <Input
                    value={n.title}
                    onChange={(e) => onUpdate(n.id, { title: e.target.value })}
                    className="bg-white/5 border-white/10"
                  />
                  <Textarea
                    value={n.content}
                    onChange={(e) => onUpdate(n.id, { content: e.target.value })}
                    className="bg-white/5 border-white/10 min-h-[100px]"
                  />
                  <Button type="button" variant="secondary" size="sm" onClick={() => setEditingId(null)}>
                    Done
                  </Button>
                </div>
              ) : (
                <>
                  <div className="flex justify-between gap-2 mb-2">
                    <h4 className="font-semibold">{n.title}</h4>
                    <div className="flex gap-2 shrink-0">
                      <button
                        type="button"
                        className="text-xs text-[#B8B2F7]"
                        onClick={() => setEditingId(n.id)}
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        className="text-xs text-red-400"
                        onClick={() => {
                          onDelete(n.id);
                          toast.success('Note removed');
                        }}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  <p className="text-sm text-[#A7ACB8] whitespace-pre-wrap">{n.content}</p>
                  <p className="text-[10px] text-[#A7ACB8]/70 mt-2">
                    Updated {formatDistanceToNow(n.updatedAt, { addSuffix: true })}
                  </p>
                </>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const PlansView = ({
  studyPlans,
  studySets,
  onCreate,
  onComplete,
}: {
  studyPlans: StudyPlan[];
  studySets: StudySet[];
  onCreate: (p: Omit<StudyPlan, 'id' | 'completed'>) => void;
  onComplete: (id: string) => void;
}) => {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [setIds, setSetIds] = useState<string[]>([]);
  const [target, setTarget] = useState(() => new Date().toISOString().slice(0, 10));
  const [dailyGoal, setDailyGoal] = useState(3);

  const submit = () => {
    if (!title.trim()) {
      toast.error('Give your plan a title');
      return;
    }
    if (!studySets.length) {
      toast.error('Create a study set first');
      return;
    }
    onCreate({
      title: title.trim(),
      description: description.trim(),
      setIds: setIds.length ? setIds : [studySets[0].id],
      targetDate: new Date(target),
      dailyGoal: Math.max(1, dailyGoal),
    });
    setTitle('');
    setDescription('');
    setSetIds([]);
    setOpen(false);
    toast.success('Plan created');
  };

  const toggleSet = (id: string) => {
    setSetIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Study plans</h2>
          <p className="text-sm text-[#A7ACB8]">Exam countdowns tied to your sets</p>
        </div>
        <Button type="button" className="btn-accent" onClick={() => setOpen(true)}>
          New plan
        </Button>
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="glass-card border-[#B8B2F7]/20 max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create study plan</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 mt-2">
            <Input
              placeholder="Title (e.g. AP Bio Unit 4)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="bg-white/5 border-white/10"
            />
            <Textarea
              placeholder="What does “done” look like?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-white/5 border-white/10 min-h-[80px]"
            />
            <label className="text-xs text-[#A7ACB8] block">Target date</label>
            <Input
              type="date"
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="bg-white/5 border-white/10"
            />
            <label className="text-xs text-[#A7ACB8] block">Daily sessions goal</label>
            <Input
              type="number"
              min={1}
              value={dailyGoal}
              onChange={(e) => setDailyGoal(Number(e.target.value))}
              className="bg-white/5 border-white/10"
            />
            <p className="text-xs text-[#A7ACB8]">Include sets</p>
            <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
              {studySets.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => toggleSet(s.id)}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                    setIds.includes(s.id) || (setIds.length === 0 && studySets.length === 1)
                      ? 'border-[#B8B2F7] bg-[#B8B2F7]/20'
                      : 'border-white/10 hover:border-white/20'
                  }`}
                >
                  {s.name}
                </button>
              ))}
            </div>
            <Button type="button" className="w-full btn-accent" onClick={submit}>
              Save plan
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      <div className="space-y-3">
        {studyPlans.length === 0 ? (
          <p className="text-[#A7ACB8] text-sm">Create a plan to track a deadline and daily pace.</p>
        ) : (
          studyPlans.map((p) => (
            <div
              key={p.id}
              className={`glass-card p-4 flex flex-wrap items-center justify-between gap-3 ${
                p.completed ? 'opacity-60' : ''
              }`}
            >
              <div>
                <h4 className="font-semibold">{p.title}</h4>
                <p className="text-sm text-[#A7ACB8]">{p.description}</p>
                <p className="text-xs text-[#A7ACB8] mt-1">
                  Due {formatDistanceToNow(p.targetDate, { addSuffix: true })} · {p.dailyGoal}{' '}
                  sessions/day
                </p>
              </div>
              {!p.completed && (
                <Button type="button" variant="outline" size="sm" onClick={() => onComplete(p.id)}>
                  Mark done
                </Button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

// Progress View
const ProgressView = ({
  userProgress,
  studySets,
  setWeeklyGoal,
}: {
  userProgress: UserProgress;
  studySets: StudySet[];
  setWeeklyGoal: (n: number) => void;
}) => {
  const [goalInput, setGoalInput] = useState(String(userProgress.weeklyGoal));
  const circumference = 2 * Math.PI * 56;
  const progressPercent = Math.min(
    (userProgress.weeklyProgress / userProgress.weeklyGoal) * 100,
    100
  );
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Your Progress</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="glass-card p-6 flex flex-col items-center">
          <div className="relative w-32 h-32 mb-4">
            <svg className="w-full h-full -rotate-90">
              <circle cx="64" cy="64" r="56" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="10" />
              <circle
                cx="64"
                cy="64"
                r="56"
                fill="none"
                stroke="#B8B2F7"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={circumference * 0.875}
                strokeDashoffset={strokeDashoffset * 0.875}
                className="progress-ring-circle"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold">{userProgress.weeklyProgress}</span>
              <span className="text-xs text-[#A7ACB8]">/ {userProgress.weeklyGoal}</span>
            </div>
          </div>
          <p className="font-medium mb-3">Weekly goal</p>
          <div className="flex gap-2 w-full max-w-[200px]">
            <Input
              type="number"
              min={1}
              value={goalInput}
              onChange={(e) => setGoalInput(e.target.value)}
              className="bg-white/5 border-white/10 h-9 text-sm"
            />
            <Button
              type="button"
              size="sm"
              variant="secondary"
              className="shrink-0"
              onClick={() => {
                const n = parseInt(goalInput, 10);
                if (Number.isFinite(n)) {
                  setWeeklyGoal(n);
                  toast.success('Weekly goal updated');
                }
              }}
            >
              Set
            </Button>
          </div>
        </div>

        <div className="glass-card p-6 flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-orange-500/20 flex items-center justify-center mb-4">
            <Flame className="w-10 h-10 text-orange-400 streak-flame" />
          </div>
          <p className="text-3xl font-bold">{userProgress.currentStreak || 0}</p>
          <p className="text-[#A7ACB8]">Day streak</p>
        </div>

        <div className="glass-card p-6 flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mb-4">
            <Target className="w-10 h-10 text-green-400" />
          </div>
          <p className="text-3xl font-bold">{Math.round(userProgress.masteryScore) || 0}%</p>
          <p className="text-[#A7ACB8]">Mastery score</p>
        </div>

        <div className="glass-card p-6 flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-[#B8B2F7]/20 flex items-center justify-center mb-4">
            <Clock className="w-10 h-10 text-[#B8B2F7]" />
          </div>
          <p className="text-3xl font-bold">{userProgress.pomodoroSessionsCompleted ?? 0}</p>
          <p className="text-[#A7ACB8] text-center text-sm">Pomodoro rounds</p>
          <p className="text-xs text-[#A7ACB8]/80 mt-1 text-center">
            ~{userProgress.totalStudyTime} min logged focus
          </p>
        </div>
      </div>

      <div className="mt-6 glass-card p-6">
        <h3 className="font-semibold mb-4">Study sets overview</h3>
        <div className="space-y-3">
          {studySets.map((set) => (
            <div key={set.id} className="flex items-center justify-between gap-4 flex-wrap">
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${set.color}20` }}
                >
                  <BookOpen className="w-4 h-4" style={{ color: set.color }} />
                </div>
                <span className="text-sm truncate">{set.name}</span>
              </div>
              <div className="flex items-center gap-4 text-sm text-[#A7ACB8]">
                <span>{set.flashcards.length} cards</span>
                <span>{set.quizQuestions.length} questions</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;