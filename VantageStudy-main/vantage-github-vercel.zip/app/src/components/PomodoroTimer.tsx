import { useCallback, useEffect, useRef, useState } from 'react';
import { Pause, Play, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

type Phase = 'work' | 'break' | 'idle';

const WORK_SEC = 25 * 60;
const BREAK_SEC = 5 * 60;

interface PomodoroTimerProps {
  onWorkComplete?: () => void;
  compact?: boolean;
}

export function PomodoroTimer({ onWorkComplete, compact }: PomodoroTimerProps) {
  const [phase, setPhase] = useState<Phase>('idle');
  const [secondsLeft, setSecondsLeft] = useState(WORK_SEC);
  const [running, setRunning] = useState(false);
  const phaseRef = useRef(phase);
  phaseRef.current = phase;
  const onWorkCompleteRef = useRef(onWorkComplete);
  onWorkCompleteRef.current = onWorkComplete;

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(id);
          setRunning(false);
          const p = phaseRef.current;
          if (p === 'work') {
            onWorkCompleteRef.current?.();
            setPhase('break');
            setSecondsLeft(BREAK_SEC);
            setTimeout(() => setRunning(true), 50);
          } else if (p === 'break') {
            setPhase('idle');
            setSecondsLeft(WORK_SEC);
          }
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [running]);

  const fmt = (s: number) => {
    const m = Math.floor(s / 60);
    const r = s % 60;
    return `${m}:${r.toString().padStart(2, '0')}`;
  };

  const label =
    phase === 'work' ? 'Focus' : phase === 'break' ? 'Break' : 'Ready';

  const toggleRun = useCallback(() => {
    if (phase === 'idle') {
      setPhase('work');
      setSecondsLeft(WORK_SEC);
      setRunning(true);
      return;
    }
    setRunning((r) => !r);
  }, [phase]);

  const reset = useCallback(() => {
    setRunning(false);
    setPhase('idle');
    setSecondsLeft(WORK_SEC);
  }, []);

  if (compact) {
    return (
      <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2">
        <span className="mono text-xs text-[#A7ACB8] w-14">{label}</span>
        <span className="mono text-sm font-semibold tabular-nums w-[3.25rem]">
          {fmt(secondsLeft)}
        </span>
        <Button
          type="button"
          size="icon"
          variant="ghost"
          className="h-8 w-8 shrink-0"
          onClick={toggleRun}
        >
          {running ? (
            <Pause className="h-4 w-4" />
          ) : (
            <Play className="h-4 w-4" />
          )}
        </Button>
        <Button
          type="button"
          size="icon"
          variant="ghost"
          className="h-8 w-8 shrink-0"
          onClick={reset}
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  return (
    <div className="glass-card p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-[#A7ACB8]">Pomodoro</span>
        <span className="text-xs text-[#B8B2F7]">{label}</span>
      </div>
      <p className="text-3xl font-bold mono tabular-nums text-center">
        {fmt(secondsLeft)}
      </p>
      <div className="flex gap-2 justify-center">
        <Button type="button" className="btn-accent" onClick={toggleRun}>
          {phase === 'idle' ? 'Start focus' : running ? 'Pause' : 'Resume'}
        </Button>
        <Button
          type="button"
          variant="outline"
          className="border-white/15 bg-transparent"
          onClick={reset}
        >
          Reset
        </Button>
      </div>
    </div>
  );
}
