export type SrsRating = 'again' | 'hard' | 'good' | 'easy';

const quality: Record<SrsRating, number> = {
  again: 1,
  hard: 3,
  good: 4,
  easy: 5,
};

export interface SrsCardState {
  easeFactor: number;
  intervalDays: number;
  repetitions: number;
}

const defaultState = (): SrsCardState => ({
  easeFactor: 2.5,
  intervalDays: 0,
  repetitions: 0,
});

/** SM-2 style scheduling; returns new state + next review date */
export function scheduleReview(
  prev: Partial<SrsCardState> | undefined,
  rating: SrsRating
): SrsCardState & { nextReview: Date } {
  const q = quality[rating];
  let easeFactor = prev?.easeFactor ?? 2.5;
  let intervalDays = prev?.intervalDays ?? 0;
  let repetitions = prev?.repetitions ?? 0;

  easeFactor = Math.max(
    1.3,
    easeFactor + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))
  );

  if (q < 3) {
    repetitions = 0;
    intervalDays = 0;
  } else {
    if (repetitions === 0) intervalDays = 1;
    else if (repetitions === 1) intervalDays = 6;
    else intervalDays = Math.max(1, Math.round(intervalDays * easeFactor));
    repetitions += 1;
  }

  const nextReview = new Date();
  if (q < 3) {
    nextReview.setMinutes(nextReview.getMinutes() + 10);
  } else {
    nextReview.setDate(nextReview.getDate() + Math.max(1, intervalDays));
  }

  return { easeFactor, intervalDays, repetitions, nextReview };
}

export function initialSrsState(): SrsCardState {
  return defaultState();
}
