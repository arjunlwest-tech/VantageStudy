import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mic, MessageSquare, Volume2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

const TutorSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const orbRef = useRef<HTMLDivElement>(null);
  const micRef = useRef<HTMLButtonElement>(null);
  
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [messages, setMessages] = useState<{role: string, content: string}[]>([
    { role: 'assistant', content: 'Hi! I\'m your AI tutor. I can help you understand any topic. What would you like to learn about?' }
  ]);
  const [inputText, setInputText] = useState('');

  // Scroll-driven animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        rightCardRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        orbRef.current,
        { scale: 0.6, opacity: 0 },
        { scale: 1, opacity: 0.75, ease: 'none' },
        0.05
      );
      scrollTl.fromTo(
        micRef.current,
        { y: '10vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      // SETTLE (30%-70%) - no animation

      // EXIT (70%-100%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        rightCardRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        orbRef.current,
        { scale: 1, opacity: 0.75 },
        { scale: 0.85, opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        micRef.current,
        { y: 0, opacity: 1 },
        { y: '8vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const speak = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.pitch = 1.1;
      utterance.rate = 1;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      speechSynthesis.speak(utterance);
    }
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;
    
    const userMessage = inputText.trim();
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setInputText('');
    setIsListening(true);

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "That's a great question! Let me break this down for you...",
        "Based on your notes, the key concept here is...",
        "I can see why this might be confusing. Here's a simpler way to think about it...",
        "This connects to what we discussed earlier. Remember that...",
      ];
      const response = responses[Math.floor(Math.random() * responses.length)];
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      speak(response);
      setIsListening(false);
    }, 1500);
  };

  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      toast.error('Voice recognition is not supported in your browser');
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputText(transcript);
      setTimeout(() => handleSendMessage(), 100);
    };

    recognition.start();
  };

  return (
    <section
      ref={sectionRef}
      id="tutor"
      className="section-pinned z-20"
    >
      <div className="w-full px-6 lg:px-14 flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12">
        {/* Left Text Card */}
        <div
          ref={leftCardRef}
          className="glass-card w-full lg:w-[42vw] lg:max-w-[560px] p-6 lg:p-8"
        >
          <span className="mono text-xs text-[#B8B2F7] uppercase tracking-wider">
            AI Voice Tutor
          </span>
          <h2 className="text-2xl lg:text-4xl font-bold mt-4 mb-4">
            Talk through tough topics like you're with a tutor.
          </h2>
          <p className="text-[#A7ACB8] leading-relaxed mb-6">
            Ask follow-ups, get explanations in your own words, and practice out
            loud—no scheduling needed.
          </p>
          <button 
            onClick={() => toast.info('Full tutor experience available in dashboard!')}
            className="btn-accent flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            Try the Tutor
          </button>
        </div>

        {/* Right Visual Card */}
        <div
          ref={rightCardRef}
          className="glass-card w-full lg:w-[40vw] lg:max-w-[520px] h-[400px] lg:h-[56vh] lg:max-h-[520px] flex flex-col relative overflow-hidden"
        >
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                    msg.role === 'user'
                      ? 'bg-[#B8B2F7] text-[#07080B] rounded-br-md'
                      : 'bg-white/10 text-[#F4F6FB] rounded-bl-md'
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
            {isListening && (
              <div className="flex justify-start">
                <div className="bg-white/10 text-[#F4F6FB] p-3 rounded-2xl rounded-bl-md">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-[#B8B2F7] rounded-full animate-bounce" />
                    <span className="w-2 h-2 bg-[#B8B2F7] rounded-full animate-bounce [animation-delay:0.1s]" />
                    <span className="w-2 h-2 bg-[#B8B2F7] rounded-full animate-bounce [animation-delay:0.2s]" />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-white/10">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ask anything..."
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm text-[#F4F6FB] placeholder:text-[#A7ACB8]/50"
              />
              <button
                onClick={handleSendMessage}
                className="p-2 bg-[#B8B2F7] rounded-xl text-[#07080B] hover:scale-105 transition-transform"
              >
                <MessageSquare className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Orb */}
          <div
            ref={orbRef}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
          >
            <div className="orb" />
          </div>

          {/* Mic Button */}
          <button
            ref={micRef}
            onClick={handleVoiceInput}
            disabled={isListening}
            className={`absolute bottom-20 left-1/2 -translate-x-1/2 w-16 h-16 rounded-full flex items-center justify-center transition-all ${
              isListening
                ? 'bg-red-500 scale-110'
                : isSpeaking
                ? 'bg-[#B8B2F7] scale-105'
                : 'bg-[#B8B2F7] hover:scale-105'
            }`}
          >
            {isSpeaking ? (
              <Volume2 className="w-6 h-6 text-[#07080B]" />
            ) : (
              <Mic className="w-6 h-6 text-[#07080B]" />
            )}
          </button>
        </div>
      </div>
    </section>
  );
};

export default TutorSection;