import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote, Star } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    quote: "The voice tutor actually feels like someone is listening. I finally explain things out loud without awkwardness.",
    author: 'Sarah M.',
    role: 'Pre-med Student',
    avatar: 'S',
    color: '#B8B2F7',
    rating: 5,
  },
  {
    quote: "I uploaded my bio notes and had a quiz ready in 30 seconds. Insanely helpful for last-minute review.",
    author: 'James K.',
    role: 'Biology Major',
    avatar: 'J',
    color: '#7DD3FC',
    rating: 5,
  },
  {
    quote: "Games make review less miserable. My retention is way up and I actually look forward to studying now.",
    author: 'Emily R.',
    role: 'Psychology Student',
    avatar: 'E',
    color: '#86EFAC',
    rating: 5,
  },
];

const TestimonialsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          },
        }
      );

      // Cards animation with parallax
      const cards = cardsRef.current?.querySelectorAll('.testimonial-card') || [];
      cards.forEach((card, index) => {
        gsap.fromTo(
          card,
          { y: 40 + index * 10, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 80%',
              end: 'top 40%',
              scrub: true,
            },
          }
        );

        // Subtle parallax on scroll
        gsap.to(card, {
          y: (index - 1) * 12,
          scrollTrigger: {
            trigger: section,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true,
          },
        });
      });
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="testimonials"
      className="section-flowing z-[90] relative"
    >
      <div className="w-full px-6 lg:px-14">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-3">
            What students are saying.
          </h2>
          <p className="text-[#A7ACB8]">
            Join thousands of students studying smarter.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto"
        >
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="testimonial-card glass-card p-6 lg:p-8 relative"
            >
              {/* Quote Icon */}
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center mb-4"
                style={{ backgroundColor: `${testimonial.color}20` }}
              >
                <Quote
                  className="w-5 h-5"
                  style={{ color: testimonial.color }}
                />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 fill-[#FDE047] text-[#FDE047]"
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-[#F4F6FB] leading-relaxed mb-6">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-[#07080B]"
                  style={{ backgroundColor: testimonial.color }}
                >
                  {testimonial.avatar}
                </div>
                <div>
                  <p className="font-medium">{testimonial.author}</p>
                  <p className="text-sm text-[#A7ACB8]">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;