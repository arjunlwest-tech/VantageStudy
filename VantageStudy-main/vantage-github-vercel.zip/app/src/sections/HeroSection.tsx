import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Play, Users } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const statRef = useRef<HTMLDivElement>(null);
  const ringsRef = useRef<HTMLDivElement>(null);

  // Entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      tl.fromTo(
        headlineRef.current?.querySelectorAll('.animate-item') || [],
        { opacity: 0, y: 24 },
        { opacity: 1, y: 0, duration: 0.8, stagger: 0.08 }
      )
        .fromTo(
          ctaRef.current?.querySelectorAll('button') || [],
          { opacity: 0, scale: 0.98 },
          { opacity: 1, scale: 1, duration: 0.6, stagger: 0.1 },
          '-=0.4'
        )
        .fromTo(
          statRef.current,
          { opacity: 0, y: 12 },
          { opacity: 1, y: 0, duration: 0.5 },
          '-=0.3'
        )
        .fromTo(
          ringsRef.current,
          { opacity: 0, scale: 0.96 },
          { opacity: 0.12, scale: 1, duration: 1 },
          '-=0.8'
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
          onLeaveBack: () => {
            // Reset elements when scrolling back to top
            gsap.set(headlineRef.current, { y: 0, opacity: 1 });
            gsap.set(ctaRef.current, { y: 0, opacity: 1 });
            gsap.set(statRef.current, { y: 0, opacity: 1 });
          },
        },
      });

      // Phase 1 (0%-70%): Hold - elements stay in place
      // Phase 2 (70%-100%): Exit
      scrollTl.fromTo(
        headlineRef.current,
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        ctaRef.current,
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        statRef.current,
        { y: 0, opacity: 1 },
        { y: '-8vh', opacity: 0, ease: 'power2.in' },
        0.8
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="section-pinned z-10"
    >
      {/* Decorative Rings */}
      <div
        ref={ringsRef}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
      >
        <div className="w-[500px] h-[500px] lg:w-[700px] lg:h-[700px] rounded-full border border-white/10 absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" />
        <div className="w-[400px] h-[400px] lg:w-[550px] lg:h-[550px] rounded-full border border-white/5 absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        {/* Headline */}
        <div ref={headlineRef} className="mb-8">
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold mb-6 leading-tight">
            <span className="animate-item block">Maximum retention.</span>
            <span className="animate-item block text-[#B8B2F7]">Minimum wasted time.</span>
          </h1>
          <p className="animate-item text-lg lg:text-xl text-[#A7ACB8] max-w-2xl mx-auto leading-relaxed">
            Paste notes once — get spaced-repetition flashcards, adaptive quizzes,
            Pomodoro sessions, and an AI study coach grounded in your content.
            Science-backed workflows, zero signup friction, runs in your browser.
          </p>
        </div>

        {/* CTAs */}
        <div ref={ctaRef} className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <button
            onClick={() => scrollToSection('how-it-works')}
            className="btn-accent flex items-center gap-2 group"
          >
            Get Started
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
          <button
            onClick={() => scrollToSection('tutor')}
            className="btn-secondary flex items-center gap-2"
          >
            <Play className="w-4 h-4" />
            See how it works
          </button>
        </div>

        {/* Social Proof */}
        <div ref={statRef} className="flex items-center justify-center gap-3">
          <div className="flex -space-x-2">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="w-8 h-8 rounded-full bg-gradient-to-br from-[#B8B2F7] to-[#7DD3FC] border-2 border-[#07080B] flex items-center justify-center text-xs font-bold text-[#07080B]"
              >
                {String.fromCharCode(64 + i)}
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 text-sm text-[#A7ACB8]">
            <Users className="w-4 h-4" />
            <span>Trusted by <strong className="text-[#F4F6FB]">12,000+</strong> students</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;