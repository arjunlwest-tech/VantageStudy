import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Mail, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

const CTASection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const buttonsRef = useRef<HTMLDivElement>(null);
  const footerRef = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // CTA block animation
      gsap.fromTo(
        ctaRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 50%',
            scrub: true,
          },
        }
      );

      // Buttons animation
      const buttons = buttonsRef.current?.querySelectorAll('button') || [];
      gsap.fromTo(
        buttons,
        { scale: 0.98, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          stagger: 0.1,
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            end: 'top 45%',
            scrub: true,
          },
        }
      );

      // Footer animation
      gsap.fromTo(
        footerRef.current,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: footerRef.current,
            start: 'top 90%',
            end: 'top 70%',
            scrub: true,
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="cta"
      className="section-flowing z-[120] relative"
    >
      {/* CTA Block */}
      <div className="w-full px-6 lg:px-14 py-16 lg:py-24">
        <div
          ref={ctaRef}
          className="glass-card max-w-3xl mx-auto text-center p-8 lg:p-16 relative overflow-hidden"
        >
          {/* Background Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#B8B2F7]/10 rounded-full blur-[100px] pointer-events-none" />

          <div className="relative z-10">
            <div className="w-16 h-16 rounded-2xl bg-[#B8B2F7]/20 flex items-center justify-center mx-auto mb-6">
              <Sparkles className="w-8 h-8 text-[#B8B2F7]" />
            </div>

            <h2 className="text-3xl lg:text-5xl font-bold mb-4">
              Ready to study smarter?
            </h2>
            <p className="text-[#A7ACB8] text-lg mb-8 max-w-xl mx-auto">
              Upload your notes. Start speaking to your tutor. See the difference today.
            </p>

            <div ref={buttonsRef} className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={() => scrollToSection('how-it-works')}
                className="btn-accent flex items-center gap-2 group"
              >
                Get Started
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                onClick={() => toast.info('Support chat coming soon! Email us at support@vantagestudy.com')}
                className="btn-secondary flex items-center gap-2"
              >
                <Mail className="w-4 h-4" />
                Contact Support
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer
        ref={footerRef}
        className="w-full px-6 lg:px-14 py-8 border-t border-white/5"
      >
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#B8B2F7]" />
              <span className="font-bold">VANTAGE</span>
            </div>

            {/* Links */}
            <nav className="flex flex-wrap items-center justify-center gap-6 text-sm text-[#A7ACB8]">
              <button onClick={() => scrollToSection('dashboard')} className="hover:text-[#F4F6FB] transition-colors">
                Dashboard
              </button>
              <button onClick={() => scrollToSection('tutor')} className="hover:text-[#F4F6FB] transition-colors">
                Tutor
              </button>
              <button onClick={() => scrollToSection('flashcards')} className="hover:text-[#F4F6FB] transition-colors">
                Flashcards
              </button>
              <button onClick={() => scrollToSection('games')} className="hover:text-[#F4F6FB] transition-colors">
                Games
              </button>
              <button onClick={() => toast.info('Privacy Policy coming soon!')} className="hover:text-[#F4F6FB] transition-colors">
                Privacy
              </button>
              <button onClick={() => toast.info('Terms of Service coming soon!')} className="hover:text-[#F4F6FB] transition-colors">
                Terms
              </button>
            </nav>
          </div>

          <div className="mt-8 pt-6 border-t border-white/5 text-center text-sm text-[#A7ACB8]">
            <p>© {new Date().getFullYear()} Vantage Study Pro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </section>
  );
};

export default CTASection;