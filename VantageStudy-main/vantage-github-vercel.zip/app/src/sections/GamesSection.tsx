import { useRef, useLayoutEffect, useState, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Gamepad2, Clock, Zap, Target } from 'lucide-react';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

interface Card {
  id: number;
  content: string;
  type: 'term' | 'definition';
  pairId: number;
}

const GamesSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchedPairs, setMatchedPairs] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [gameStarted, setGameStarted] = useState(false);

  // Sample matching game data
  const gameData = [
    { term: 'Mitosis', definition: 'Cell division' },
    { term: 'Photosynthesis', definition: 'Light to energy' },
    { term: 'DNA', definition: 'Genetic code' },
  ];

  useEffect(() => {
    // Initialize cards
    const allCards: Card[] = [];
    gameData.forEach((item, index) => {
      allCards.push(
        { id: index * 2, content: item.term, type: 'term', pairId: index },
        { id: index * 2 + 1, content: item.definition, type: 'definition', pairId: index }
      );
    });
    setCards(allCards.sort(() => Math.random() - 0.5));
  }, []);

  useEffect(() => {
    if (gameStarted && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(t => t - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && gameStarted) {
      toast.info('Time\'s up! Try again.');
      setGameStarted(false);
    }
  }, [timeLeft, gameStarted]);

  // Scroll-driven animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        rightCardRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Grid cards stagger
      const gridCards = gridRef.current?.querySelectorAll('.matching-card') || [];
      scrollTl.fromTo(
        gridCards,
        { y: '6vh', scale: 0.92, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, stagger: 0.015, ease: 'none' },
        0.08
      );

      // SETTLE (30%-70%) - no animation

      // EXIT (70%-100%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        rightCardRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        gridCards,
        { scale: 1, opacity: 1 },
        { scale: 0.95, opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleCardClick = (cardId: number) => {
    if (!gameStarted) {
      setGameStarted(true);
    }
    
    if (flippedCards.length === 2 || flippedCards.includes(cardId)) return;
    
    const newFlipped = [...flippedCards, cardId];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      const card1 = cards.find(c => c.id === newFlipped[0]);
      const card2 = cards.find(c => c.id === newFlipped[1]);
      
      if (card1?.pairId === card2?.pairId && card1) {
        setMatchedPairs(prev => [...prev, card1.pairId]);
        setScore(s => s + 100);
        setFlippedCards([]);
        
        if (matchedPairs.length + 1 === gameData.length) {
          toast.success(`Congratulations! You scored ${score + 100} points!`);
        }
      } else {
        setTimeout(() => setFlippedCards([]), 1000);
      }
    }
  };

  const isFlipped = (cardId: number) => flippedCards.includes(cardId);
  const isMatched = (pairId: number) => matchedPairs.includes(pairId);

  return (
    <section
      ref={sectionRef}
      id="games"
      className="section-pinned z-50"
    >
      <div className="w-full px-6 lg:px-14 flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12">
        {/* Left Visual Card */}
        <div
          ref={leftCardRef}
          className="glass-card w-full lg:w-[40vw] lg:max-w-[520px] h-[400px] lg:h-[56vh] lg:max-h-[520px] flex flex-col relative overflow-hidden order-2 lg:order-1"
        >
          {/* Game Header */}
          <div className="flex items-center justify-between p-4 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-[#B8B2F7]" />
              <span className="text-sm font-medium">Matching Game</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1 text-sm text-[#A7ACB8]">
                <Clock className="w-4 h-4" />
                <span>{timeLeft}s</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-[#B8B2F7]">
                <Zap className="w-4 h-4" />
                <span>{score}</span>
              </div>
            </div>
          </div>

          {/* Game Grid */}
          <div className="flex-1 p-4 flex items-center justify-center">
            <div
              ref={gridRef}
              className="grid grid-cols-2 gap-3 w-full max-w-[320px]"
            >
              {cards.map((card) => (
                <button
                  key={card.id}
                  onClick={() => handleCardClick(card.id)}
                  className={`matching-card text-sm py-4 ${
                    isFlipped(card.id) || isMatched(card.pairId)
                      ? isMatched(card.pairId)
                        ? 'matched'
                        : 'flipped'
                      : ''
                  }`}
                  disabled={isMatched(card.pairId)}
                >
                  {(isFlipped(card.id) || isMatched(card.pairId)) ? (
                    card.content
                  ) : (
                    <span className="text-2xl">?</span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Speed Run Hint */}
          <div className="px-4 pb-4 flex justify-center gap-2">
            <span className="text-xs text-[#A7ACB8]">Also try:</span>
            <span className="text-xs text-[#B8B2F7]">Speed Run</span>
            <span className="text-xs text-[#A7ACB8]">•</span>
            <span className="text-xs text-[#B8B2F7]">Memory Challenge</span>
          </div>
        </div>

        {/* Right Text Card */}
        <div
          ref={rightCardRef}
          className="glass-card w-full lg:w-[42vw] lg:max-w-[560px] p-6 lg:p-8 order-1 lg:order-2"
        >
          <span className="mono text-xs text-[#B8B2F7] uppercase tracking-wider">
            Study Games
          </span>
          <h2 className="text-2xl lg:text-4xl font-bold mt-4 mb-4">
            Make review feel like play.
          </h2>
          <p className="text-[#A7ACB8] leading-relaxed mb-6">
            Match terms, beat the clock, and build streaks. Games are built from
            your notes so every round is relevant.
          </p>
          <button 
            onClick={() => document.getElementById('dashboard')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-accent flex items-center gap-2"
          >
            <Gamepad2 className="w-4 h-4" />
            Play a Game
          </button>
        </div>
      </div>
    </section>
  );
};

export default GamesSection;