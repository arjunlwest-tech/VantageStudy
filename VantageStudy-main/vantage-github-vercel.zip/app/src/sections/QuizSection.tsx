import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CheckCircle, HelpCircle, Trophy } from 'lucide-react';
import { useStudyStore } from '@/hooks/useStudyStore';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

const QuizSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const quizCardRef = useRef<HTMLDivElement>(null);
  const optionsRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const { studySets } = useStudyStore();

  // Sample quiz question
  const sampleQuestion = {
    question: 'Which of the following best describes cellular respiration?',
    options: [
      'The process of converting glucose into ATP energy',
      'The process of photosynthesis in plants',
      'The breakdown of proteins into amino acids',
      'The synthesis of DNA from RNA templates',
    ],
    correctAnswer: 0,
    explanation: 'Cellular respiration is the metabolic process that converts glucose into ATP, the energy currency of cells.',
  };

  const quizQuestion = studySets[0]?.quizQuestions?.[0] || sampleQuestion;

  // Scroll-driven animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        rightCardRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        quizCardRef.current,
        { y: '12vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.08
      );

      // Options stagger
      const options = optionsRef.current?.querySelectorAll('.quiz-option') || [];
      scrollTl.fromTo(
        options,
        { x: '4vw', opacity: 0 },
        { x: 0, opacity: 1, stagger: 0.02, ease: 'none' },
        0.1
      );

      scrollTl.fromTo(
        progressRef.current,
        { scaleX: 0 },
        { scaleX: 1, ease: 'none' },
        0.12
      );

      // SETTLE (30%-70%) - no animation

      // EXIT (70%-100%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        rightCardRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        quizCardRef.current,
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        options,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.72
      );
      scrollTl.fromTo(
        progressRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.72
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSelect = (index: number) => {
    if (showResult) return;
    setSelectedOption(index);
    setShowResult(true);
    
    if (index === quizQuestion.correctAnswer) {
      toast.success('Correct! Great job!');
    } else {
      toast.error('Not quite. Keep studying!');
    }
  };

  return (
    <section
      ref={sectionRef}
      id="quiz"
      className="section-pinned z-40"
    >
      <div className="w-full px-6 lg:px-14 flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12">
        {/* Left Text Card */}
        <div
          ref={leftCardRef}
          className="glass-card w-full lg:w-[42vw] lg:max-w-[560px] p-6 lg:p-8"
        >
          <span className="mono text-xs text-[#B8B2F7] uppercase tracking-wider">
            Quiz Mode
          </span>
          <h2 className="text-2xl lg:text-4xl font-bold mt-4 mb-4">
            Test yourself before the exam.
          </h2>
          <p className="text-[#A7ACB8] leading-relaxed mb-6">
            Multiple choice, fill-in-the-blank, and explain-it prompts—generated
            from your material with instant feedback.
          </p>
          <button 
            onClick={() => document.getElementById('dashboard')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-accent flex items-center gap-2"
          >
            <Trophy className="w-4 h-4" />
            Start a Quiz
          </button>
        </div>

        {/* Right Visual Card */}
        <div
          ref={rightCardRef}
          className="glass-card w-full lg:w-[40vw] lg:max-w-[520px] h-auto min-h-[400px] lg:min-h-[480px] flex flex-col relative overflow-hidden"
        >
          {/* Progress Bar */}
          <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
            <div
              ref={progressRef}
              className="h-full bg-[#B8B2F7] origin-left"
              style={{ width: '60%' }}
            />
          </div>

          {/* Quiz Content */}
          <div ref={quizCardRef} className="flex-1 p-6 flex flex-col">
            <div className="flex items-center gap-2 mb-4">
              <HelpCircle className="w-5 h-5 text-[#B8B2F7]" />
              <span className="text-sm text-[#A7ACB8]">Question 3 of 5</span>
            </div>

            <h3 className="text-lg font-semibold mb-6 text-[#F4F6FB]">
              {quizQuestion.question}
            </h3>

            <div ref={optionsRef} className="space-y-3">
              {quizQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleSelect(index)}
                  className={`quiz-option w-full text-left flex items-center gap-3 ${
                    showResult
                      ? index === quizQuestion.correctAnswer
                        ? 'correct'
                        : selectedOption === index
                        ? 'incorrect'
                        : ''
                      : selectedOption === index
                      ? 'selected'
                      : ''
                  }`}
                  disabled={showResult}
                >
                  <span className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-xs font-medium">
                    {String.fromCharCode(65 + index)}
                  </span>
                  <span className="flex-1">{option}</span>
                  {showResult && index === quizQuestion.correctAnswer && (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  )}
                </button>
              ))}
            </div>

            {showResult && (
              <div className="mt-4 p-4 bg-[#B8B2F7]/10 rounded-xl border border-[#B8B2F7]/20">
                <p className="text-sm text-[#A7ACB8]">
                  <strong className="text-[#F4F6FB]">Explanation:</strong>{' '}
                  {quizQuestion.explanation}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default QuizSection;