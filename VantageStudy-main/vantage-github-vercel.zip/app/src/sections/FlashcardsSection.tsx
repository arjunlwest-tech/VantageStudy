import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { RotateCw, ChevronLeft, ChevronRight, Layers } from 'lucide-react';
import { useStudyStore } from '@/hooks/useStudyStore';

gsap.registerPlugin(ScrollTrigger);

const FlashcardsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const flashcardRef = useRef<HTMLDivElement>(null);
  const flipIconRef = useRef<HTMLButtonElement>(null);

  const [isFlipped, setIsFlipped] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const { studySets } = useStudyStore();
  
  // Sample flashcards if no study sets exist
  const sampleFlashcards = [
    { front: 'What is photosynthesis?', back: 'The process by which plants convert light energy into chemical energy stored in glucose.' },
    { front: 'Define mitosis', back: 'Cell division that results in two daughter cells with identical genetic material.' },
    { front: 'What is the Krebs cycle?', back: 'A series of chemical reactions used by all aerobic organisms to generate energy.' },
  ];
  
  const flashcards = studySets[0]?.flashcards?.slice(0, 3) || sampleFlashcards.map((f, i) => ({
    id: String(i),
    front: f.front,
    back: f.back,
    difficulty: 'medium' as const,
    timesReviewed: 0,
    timesCorrect: 0,
  }));

  // Scroll-driven animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE (0%-30%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: '-50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        rightCardRef.current,
        { x: '50vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.fromTo(
        flashcardRef.current,
        { y: '12vh', rotateX: 18, opacity: 0 },
        { y: 0, rotateX: 0, opacity: 1, ease: 'none' },
        0.08
      );
      scrollTl.fromTo(
        flipIconRef.current,
        { scale: 0.8, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.12
      );

      // SETTLE (30%-70%) - no animation

      // EXIT (70%-100%)
      scrollTl.fromTo(
        leftCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        rightCardRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        flashcardRef.current,
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.7
      );
      scrollTl.fromTo(
        flipIconRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const nextCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % flashcards.length);
    }, 200);
  };

  const prevCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + flashcards.length) % flashcards.length);
    }, 200);
  };

  return (
    <section
      ref={sectionRef}
      id="flashcards"
      className="section-pinned z-30"
    >
      <div className="w-full px-6 lg:px-14 flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-12">
        {/* Left Visual Card */}
        <div
          ref={leftCardRef}
          className="glass-card w-full lg:w-[40vw] lg:max-w-[520px] h-[400px] lg:h-[56vh] lg:max-h-[520px] flex flex-col items-center justify-center relative order-2 lg:order-1"
        >
          {/* Deck hint behind */}
          <div className="absolute w-[78%] aspect-[16/10] rounded-[18px] bg-white/[0.04] translate-x-3 translate-y-3" />
          <div className="absolute w-[78%] aspect-[16/10] rounded-[18px] bg-white/[0.06] translate-x-1.5 translate-y-1.5" />

          {/* Flashcard */}
          <div
            ref={flashcardRef}
            className="flashcard w-[78%] cursor-pointer"
            onClick={() => setIsFlipped(!isFlipped)}
            style={{ perspective: '1000px' }}
          >
            <div
              className={`flashcard-inner ${isFlipped ? 'flipped' : ''}`}
              style={{ transformStyle: 'preserve-3d' }}
            >
              <div className="flashcard-front">
                <div>
                  <p className="text-lg font-semibold mb-4">
                    {flashcards[currentIndex]?.front}
                  </p>
                  <span className="text-xs text-[#A7ACB8]">Click to flip</span>
                </div>
              </div>
              <div className="flashcard-back">
                <p className="text-base leading-relaxed">
                  {flashcards[currentIndex]?.back}
                </p>
              </div>
            </div>
          </div>

          {/* Flip Icon */}
          <button
            ref={flipIconRef}
            onClick={() => setIsFlipped(!isFlipped)}
            className="absolute bottom-8 w-12 h-12 rounded-full bg-[#B8B2F7] flex items-center justify-center pulse-subtle hover:scale-110 transition-transform"
          >
            <RotateCw className="w-5 h-5 text-[#07080B]" />
          </button>

          {/* Navigation */}
          <div className="absolute bottom-8 right-8 flex gap-2">
            <button
              onClick={prevCard}
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={nextCard}
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Card Counter */}
          <div className="absolute top-6 right-6 text-sm text-[#A7ACB8]">
            {currentIndex + 1} / {flashcards.length}
          </div>
        </div>

        {/* Right Text Card */}
        <div
          ref={rightCardRef}
          className="glass-card w-full lg:w-[42vw] lg:max-w-[560px] p-6 lg:p-8 order-1 lg:order-2"
        >
          <span className="mono text-xs text-[#B8B2F7] uppercase tracking-wider">
            Smart Flashcards
          </span>
          <h2 className="text-2xl lg:text-4xl font-bold mt-4 mb-4">
            Turn notes into cards—automatically.
          </h2>
          <p className="text-[#A7ACB8] leading-relaxed mb-6">
            Upload a PDF or paste notes. We generate question/answer cards you can
            flip, shuffle, and master.
          </p>
          <button 
            onClick={() => document.getElementById('dashboard')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-accent flex items-center gap-2"
          >
            <Layers className="w-4 h-4" />
            Create a Deck
          </button>
        </div>
      </div>
    </section>
  );
};

export default FlashcardsSection;