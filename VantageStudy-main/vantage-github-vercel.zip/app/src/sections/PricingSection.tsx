import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Sparkles, Users, Zap } from 'lucide-react';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    description: 'Perfect for trying out',
    icon: Zap,
    color: '#A7ACB8',
    features: [
      '3 study sets',
      'Basic flashcards',
      'Limited quizzes',
      'Community support',
    ],
    cta: 'Get Started',
    highlighted: false,
  },
  {
    name: 'Pro',
    price: '$8',
    period: '/month',
    description: 'Everything you need to excel',
    icon: Sparkles,
    color: '#B8B2F7',
    features: [
      'Unlimited study sets',
      'AI voice tutor',
      'Study games',
      'Advanced analytics',
      'Priority support',
      'Export to PDF/Anki',
    ],
    cta: 'Start Free Trial',
    highlighted: true,
  },
  {
    name: 'Teams',
    price: '$12',
    period: '/seat/month',
    description: 'For study groups & classes',
    icon: Users,
    color: '#7DD3FC',
    features: [
      'Everything in Pro',
      'Shared decks',
      'Admin insights',
      'Collaboration tools',
      'SSO & SAML',
      'Dedicated support',
    ],
    cta: 'Contact Sales',
    highlighted: false,
  },
];

const PricingSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          },
        }
      );

      // Cards animation
      const cards = cardsRef.current?.querySelectorAll('.pricing-card') || [];
      gsap.fromTo(
        cards,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
            end: 'top 45%',
            scrub: true,
          },
        }
      );

      // Pro card scale animation
      const proCard = cardsRef.current?.querySelector('.pricing-card-highlighted');
      if (proCard) {
        gsap.fromTo(
          proCard,
          { scale: 0.98 },
          {
            scale: 1,
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 80%',
              end: 'top 45%',
              scrub: true,
            },
          }
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const handleCTA = (planName: string) => {
    if (planName === 'Free') {
      toast.success('Welcome to Vantage! Start creating your first study set.');
    } else if (planName === 'Pro') {
      toast.info('Pro features are currently FREE during our beta! Enjoy!');
    } else {
      toast.info('Teams plan coming soon. Contact us for early access.');
    }
  };

  return (
    <section
      ref={sectionRef}
      id="pricing"
      className="section-flowing z-[100] relative"
    >
      <div className="w-full px-6 lg:px-14">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-3">
            Simple pricing.
          </h2>
          <p className="text-[#A7ACB8] mb-8">
            Start free. Upgrade when you're ready.
          </p>

          {/* Billing Toggle */}
          <div className="inline-flex items-center gap-3 p-1 bg-white/5 rounded-xl">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-[#B8B2F7] text-[#07080B]'
                  : 'text-[#A7ACB8] hover:text-[#F4F6FB]'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                billingCycle === 'yearly'
                  ? 'bg-[#B8B2F7] text-[#07080B]'
                  : 'text-[#A7ACB8] hover:text-[#F4F6FB]'
              }`}
            >
              Yearly
              <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto"
        >
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`pricing-card ${
                plan.highlighted ? 'pricing-card-highlighted' : ''
              } glass-card p-6 lg:p-8 relative ${
                plan.highlighted
                  ? 'border-[#B8B2F7]/40 shadow-[0_0_40px_rgba(184,178,247,0.15)]'
                  : ''
              }`}
            >
              {/* Popular Badge */}
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-[#B8B2F7] text-[#07080B] text-xs font-bold px-3 py-1 rounded-full">
                    MOST POPULAR
                  </span>
                </div>
              )}

              {/* Plan Header */}
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${plan.color}20` }}
                >
                  <plan.icon
                    className="w-5 h-5"
                    style={{ color: plan.color }}
                  />
                </div>
                <div>
                  <h3 className="font-bold">{plan.name}</h3>
                  <p className="text-xs text-[#A7ACB8]">{plan.description}</p>
                </div>
              </div>

              {/* Price */}
              <div className="mb-6">
                <span className="text-4xl font-bold">{plan.price}</span>
                <span className="text-[#A7ACB8]">
                  {billingCycle === 'yearly' && plan.name !== 'Free'
                    ? '/month billed annually'
                    : plan.period}
                </span>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm">
                    <Check
                      className="w-4 h-4 flex-shrink-0"
                      style={{ color: plan.color }}
                    />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <button
                onClick={() => handleCTA(plan.name)}
                className={`w-full py-3 rounded-xl font-medium transition-all ${
                  plan.highlighted
                    ? 'btn-accent'
                    : 'bg-white/5 hover:bg-white/10 text-[#F4F6FB]'
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>

        {/* Trust Badges */}
        <div className="text-center mt-12">
          <p className="text-sm text-[#A7ACB8]">
            No credit card required for free plan. Cancel anytime.
          </p>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;