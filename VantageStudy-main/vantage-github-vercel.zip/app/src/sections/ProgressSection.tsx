import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Target, Flame, TrendingUp, Calendar, Award } from 'lucide-react';
import { useStudyStore } from '@/hooks/useStudyStore';

gsap.registerPlugin(ScrollTrigger);

const ProgressSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardsRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<SVGCircleElement>(null);

  const { userProgress, studySessions } = useStudyStore();

  // Calculate progress percentage
  const progressPercent = Math.min(
    (userProgress.weeklyProgress / userProgress.weeklyGoal) * 100,
    100
  );
  const circumference = 2 * Math.PI * 80;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 18, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          },
        }
      );

      // Left card animation
      gsap.fromTo(
        leftCardRef.current,
        { x: '-6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            end: 'top 45%',
            scrub: true,
          },
        }
      );

      // Progress ring animation
      gsap.fromTo(
        ringRef.current,
        { strokeDashoffset: circumference },
        {
          strokeDashoffset,
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            end: 'top 40%',
            scrub: true,
          },
        }
      );

      // Right cards animation
      const cards = rightCardsRef.current?.querySelectorAll('.stat-card') || [];
      gsap.fromTo(
        cards,
        { x: '6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          stagger: 0.1,
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            end: 'top 40%',
            scrub: true,
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, [strokeDashoffset, circumference]);

  const stats = [
    {
      icon: Flame,
      label: 'Current Streak',
      value: `${userProgress.currentStreak || 8} days`,
      color: '#F97316',
      subtext: 'Longest: 15 days',
    },
    {
      icon: TrendingUp,
      label: 'Mastery Score',
      value: `${Math.round(userProgress.masteryScore) || 74}%`,
      color: '#22C55E',
      subtext: '+12% this week',
    },
  ];

  return (
    <section
      ref={sectionRef}
      id="progress"
      className="section-flowing z-[80] relative"
    >
      <div className="w-full px-6 lg:px-14">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-3">
            Track progress. Stay motivated.
          </h2>
          <p className="text-[#A7ACB8]">
            Watch your knowledge grow with every study session.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {/* Left - Weekly Goal */}
          <div
            ref={leftCardRef}
            className="glass-card p-8 flex flex-col items-center justify-center"
          >
            <div className="relative w-48 h-48 mb-6">
              {/* Background Ring */}
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="80"
                  fill="none"
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="12"
                />
                {/* Progress Ring */}
                <circle
                  ref={ringRef}
                  cx="96"
                  cy="96"
                  r="80"
                  fill="none"
                  stroke="#B8B2F7"
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={circumference}
                  className="progress-ring-circle"
                />
              </svg>
              {/* Center Text */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-bold">
                  {userProgress.weeklyProgress || 12}
                </span>
                <span className="text-sm text-[#A7ACB8]">
                  / {userProgress.weeklyGoal || 20} sessions
                </span>
              </div>
            </div>

            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Target className="w-5 h-5 text-[#B8B2F7]" />
                <span className="font-semibold">Weekly Goal</span>
              </div>
              <p className="text-sm text-[#A7ACB8]">
                {progressPercent.toFixed(0)}% complete • Keep it up!
              </p>
            </div>
          </div>

          {/* Right - Stats */}
          <div ref={rightCardsRef} className="space-y-6">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="stat-card glass-card p-6 flex items-center gap-6"
              >
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}20` }}
                >
                  <stat.icon
                    className="w-7 h-7"
                    style={{ color: stat.color }}
                  />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-[#A7ACB8] mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-[#A7ACB8] mt-1">{stat.subtext}</p>
                </div>
              </div>
            ))}

            {/* Additional Mini Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="stat-card glass-card p-4 text-center">
                <Calendar className="w-5 h-5 text-[#7DD3FC] mx-auto mb-2" />
                <p className="text-2xl font-bold">{studySessions.length || 24}</p>
                <p className="text-xs text-[#A7ACB8]">Total Sessions</p>
              </div>
              <div className="stat-card glass-card p-4 text-center">
                <Award className="w-5 h-5 text-[#FDE047] mx-auto mb-2" />
                <p className="text-2xl font-bold">{userProgress.totalStudySets || 6}</p>
                <p className="text-xs text-[#A7ACB8]">Study Sets</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProgressSection;