import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Upload, Wand2, BookOpen, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    icon: Upload,
    title: 'Upload your notes',
    description: 'PDF, paste text, or import from Notion. We handle the rest.',
    color: '#B8B2F7',
  },
  {
    icon: Wand2,
    title: 'Generate materials',
    description: 'Flashcards, quizzes, and a tutor—auto-built from your content.',
    color: '#7DD3FC',
  },
  {
    icon: BookOpen,
    title: 'Study your way',
    description: 'Solo review, voice chat, or competitive games. You choose.',
    color: '#86EFAC',
  },
];

const HowItWorksSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          },
        }
      );

      // Cards stagger animation
      const cards = cardsRef.current?.querySelectorAll('.step-card') || [];
      gsap.fromTo(
        cards,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
            end: 'top 45%',
            scrub: true,
          },
        }
      );

      // Connector line animation
      gsap.fromTo(
        lineRef.current,
        { scaleX: 0 },
        {
          scaleX: 1,
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 70%',
            end: 'top 40%',
            scrub: true,
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="how-it-works"
      className="section-flowing z-[60] relative"
    >
      <div className="w-full px-6 lg:px-14">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold mb-4">
            Three steps to better study sessions.
          </h2>
          <p className="text-[#A7ACB8] text-lg max-w-2xl mx-auto">
            Get started in minutes. No complicated setup, no learning curve.
          </p>
        </div>

        {/* Steps Grid */}
        <div ref={cardsRef} className="relative max-w-5xl mx-auto">
          {/* Connector Line (desktop only) */}
          <div
            ref={lineRef}
            className="hidden lg:block absolute top-16 left-[16.67%] right-[16.67%] h-0.5 bg-gradient-to-r from-[#B8B2F7] via-[#7DD3FC] to-[#86EFAC] origin-left"
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
            {steps.map((step, index) => (
              <div
                key={index}
                className="step-card glass-card p-6 lg:p-8 relative group hover:-translate-y-2 transition-transform duration-300"
              >
                {/* Step Number */}
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-6"
                  style={{ backgroundColor: `${step.color}20` }}
                >
                  <step.icon
                    className="w-6 h-6"
                    style={{ color: step.color }}
                  />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                <p className="text-[#A7ACB8] leading-relaxed">
                  {step.description}
                </p>

                {/* Step Indicator */}
                <div className="mt-6 flex items-center gap-2">
                  <span
                    className="text-sm font-medium"
                    style={{ color: step.color }}
                  >
                    Step {index + 1}
                  </span>
                  <ArrowRight
                    className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all"
                    style={{ color: step.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;