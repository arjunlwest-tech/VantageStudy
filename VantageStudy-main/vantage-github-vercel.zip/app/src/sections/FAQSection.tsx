import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

gsap.registerPlugin(ScrollTrigger);

const faqs = [
  {
    question: 'How is this different from Quizlet or Anki?',
    answer:
      'Vantage combines active recall (quizzes), SM-2 style spaced repetition on flashcards, Pomodoro focus, per-set notes, and study plans—in one dashboard. You stay inside your browser with no account required for the core workflow.',
  },
  {
    question: 'Where is my data stored?',
    answer:
      'Study sets, progress, and notes are saved in your browser (local storage). Use Export backup in the dashboard to download a JSON file, and Import backup to restore or move to another device.',
  },
  {
    question: 'How do I add material?',
    answer:
      'Paste notes or textbook text when you create a set. Vantage generates starter flashcards and multiple-choice questions from your wording. You can edit cards, add your own, and run Learn mode for scheduling.',
  },
  {
    question: 'Does the coach connect to a real AI API?',
    answer:
      'The study coach uses your pasted notes to pull relevant sentences and give Socratic prompts—it is not a live large-model backend in this build. Pair it with Learn mode and quizzes for the strongest results.',
  },
  {
    question: 'Will this guarantee a specific exam score?',
    answer:
      'No app can promise a grade. Vantage is built around evidence-based habits (spacing, retrieval practice, focused time). Your outcomes still depend on your material, sleep, and how you use the tools.',
  },
  {
    question: 'Does it work on mobile?',
    answer:
      'Yes. Use a modern mobile browser. Voice features depend on OS support for speech recognition and synthesis (Chrome and Safari generally work well).',
  },
];

const FAQSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const accordionRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          },
        }
      );

      // Accordion items animation
      const items = accordionRef.current?.querySelectorAll('[data-faq-item]') || [];
      gsap.fromTo(
        items,
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.08,
          scrollTrigger: {
            trigger: accordionRef.current,
            start: 'top 80%',
            end: 'top 50%',
            scrub: true,
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="faq"
      className="section-flowing z-[110] relative"
    >
      <div className="w-full px-6 lg:px-14">
        {/* Header */}
        <div ref={headerRef} className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-3">
            Questions? Answers.
          </h2>
          <p className="text-[#A7ACB8]">
            Everything you need to know about Vantage.
          </p>
        </div>

        {/* Accordion */}
        <div
          ref={accordionRef}
          className="max-w-3xl mx-auto"
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                data-faq-item
                className="glass-card border-none px-6"
              >
                <AccordionTrigger className="text-left hover:no-underline py-5">
                  <span className="font-medium text-[#F4F6FB]">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="text-[#A7ACB8] pb-5 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Contact CTA */}
        <div className="text-center mt-12">
          <p className="text-[#A7ACB8] mb-4">
            Still have questions?
          </p>
          <button 
            onClick={() => window.open('mailto:support@vantagestudy.com', '_blank')}
            className="btn-secondary"
          >
            Contact Support
          </button>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;