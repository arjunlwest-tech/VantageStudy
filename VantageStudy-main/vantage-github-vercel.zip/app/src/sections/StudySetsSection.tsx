import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Plus, BookOpen, MoreVertical, Clock, Layers } from 'lucide-react';
import { useStudyStore } from '@/hooks/useStudyStore';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

gsap.registerPlugin(ScrollTrigger);

const sampleSets = [
  { name: 'Organic Chemistry', cards: 42, lastStudied: '2 hours ago', color: '#B8B2F7' },
  { name: 'Macroeconomics', cards: 28, lastStudied: '1 day ago', color: '#7DD3FC' },
  { name: 'Psychology 101', cards: 56, lastStudied: '3 days ago', color: '#86EFAC' },
  { name: 'History: Cold War', cards: 34, lastStudied: '1 week ago', color: '#FDE047' },
  { name: 'CS: Data Structures', cards: 67, lastStudied: '2 days ago', color: '#FCA5A5' },
  { name: 'Spanish Vocabulary', cards: 120, lastStudied: '5 hours ago', color: '#C4B5FD' },
];

const StudySetsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  
  const { studySets, createStudySet } = useStudyStore();
  const [newSetName, setNewSetName] = useState('');
  const [newSetContent, setNewSetContent] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const displaySets = studySets.length > 0 
    ? studySets.slice(0, 6).map(s => ({ 
        name: s.name, 
        cards: s.flashcards.length, 
        lastStudied: 'Just now',
        color: s.color 
      }))
    : sampleSets;

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        headerRef.current,
        { y: 18, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          },
        }
      );

      // Grid cards animation
      const cards = gridRef.current?.querySelectorAll('.study-set-card') || [];
      gsap.fromTo(
        cards,
        { y: 60, scale: 0.98, opacity: 0 },
        {
          y: 0,
          scale: 1,
          opacity: 1,
          stagger: 0.08,
          scrollTrigger: {
            trigger: gridRef.current,
            start: 'top 75%',
            end: 'top 40%',
            scrub: true,
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleCreateSet = () => {
    if (!newSetName.trim() || !newSetContent.trim()) {
      toast.error('Please fill in all fields');
      return;
    }
    createStudySet(newSetName, newSetContent);
    setNewSetName('');
    setNewSetContent('');
    setIsDialogOpen(false);
    toast.success('Study set created successfully!');
  };

  return (
    <section
      ref={sectionRef}
      id="study-sets"
      className="section-flowing z-[70] relative"
    >
      <div className="w-full px-6 lg:px-14">
        {/* Header */}
        <div ref={headerRef} className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-10">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold mb-2">
              Your study sets.
            </h2>
            <p className="text-[#A7ACB8]">
              Everything you've uploaded—organized, searchable, ready to review.
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <button className="btn-accent flex items-center gap-2 self-start">
                <Plus className="w-4 h-4" />
                Create New Set
              </button>
            </DialogTrigger>
            <DialogContent className="glass-card border-[#B8B2F7]/20 max-w-lg">
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold text-[#F4F6FB]">
                  Create New Study Set
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div>
                  <label className="text-sm text-[#A7ACB8] mb-2 block">
                    Subject Name
                  </label>
                  <Input
                    value={newSetName}
                    onChange={(e) => setNewSetName(e.target.value)}
                    placeholder="e.g., Organic Chemistry"
                    className="bg-white/5 border-white/10 text-[#F4F6FB] placeholder:text-[#A7ACB8]/50"
                  />
                </div>
                <div>
                  <label className="text-sm text-[#A7ACB8] mb-2 block">
                    Your Notes
                  </label>
                  <Textarea
                    value={newSetContent}
                    onChange={(e) => setNewSetContent(e.target.value)}
                    placeholder="Paste your notes, textbook content, or any study material here..."
                    className="bg-white/5 border-white/10 text-[#F4F6FB] placeholder:text-[#A7ACB8]/50 min-h-[200px]"
                  />
                </div>
                <Button
                  onClick={handleCreateSet}
                  className="w-full btn-accent"
                >
                  Create Study Set
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          {displaySets.map((set, index) => (
            <div
              key={index}
              className="study-set-card group cursor-pointer"
              onClick={() => toast.info(`Opening ${set.name}...`)}
            >
              <div className="flex items-start justify-between mb-4">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${set.color}20` }}
                >
                  <BookOpen
                    className="w-5 h-5"
                    style={{ color: set.color }}
                  />
                </div>
                <button 
                  className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-white/10 rounded"
                  onClick={(e) => {
                    e.stopPropagation();
                    toast.info('Options menu coming soon!');
                  }}
                >
                  <MoreVertical className="w-4 h-4 text-[#A7ACB8]" />
                </button>
              </div>

              <h3 className="text-lg font-semibold mb-2 group-hover:text-[#B8B2F7] transition-colors">
                {set.name}
              </h3>

              <div className="flex items-center gap-4 text-sm text-[#A7ACB8]">
                <div className="flex items-center gap-1">
                  <Layers className="w-4 h-4" />
                  <span>{set.cards} cards</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{set.lastStudied}</span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-4 h-1 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.random() * 40 + 20}%`,
                    backgroundColor: set.color,
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StudySetsSection;